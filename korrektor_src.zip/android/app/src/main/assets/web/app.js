// Корректор NC — мобильная версия. Всё как в настольной программе:
// код с инструментом по строкам, 2D/3D, проигрывание, инструменты/коды/проверки,
// координаты и линейка, редактор режимов, настройки.
import * as N from "./nc.js";
import { View2D } from "./view2d.js";

const $ = id => document.getElementById(id);
const ROWH = 22;
const CFG_KEY = "korrektor_cfg_v1";
const TOOL_TYPES = { mill: "Фреза", drill: "Сверло" };
const DEFAULT_CFG = {
  rapid_feed: 30000, max_depth: -18, spindle_codes: "",
  tools: { 1: { name: "", d: 6, type: "mill" }, 2: { name: "", d: 6, type: "mill" }, 3: { name: "", d: 6, type: "mill" } },
  tint_lines: true, stock_thickness: 16, z_zero: "top", stock_auto: true, stock_x: 2750, stock_y: 1830,
  sim_cell: 3, speed: 40, edit_rules: {}, ramp_clear: 1,
};

// ------------------------------------------------------------------ настройки
function loadCfg() {
  const c = JSON.parse(JSON.stringify(DEFAULT_CFG));
  try { const d = JSON.parse(localStorage.getItem(CFG_KEY) || "{}"); for (const k in d) if (k in c) c[k] = d[k]; } catch (e) { /* нет хранилища */ }
  return c;
}
function saveCfg() { try { localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); } catch (e) { /* нет хранилища */ } }
let cfg = loadCfg();
const toolCfg = t => {
  let raw = cfg.tools[String(t)];
  if (typeof raw === "string") raw = { name: raw };
  raw = raw || {};
  const d = Number(raw.d) > 0 ? Number(raw.d) : 6;
  return { name: String(raw.name || ""), d, type: raw.type === "drill" ? "drill" : "mill" };
};
const toolRadius = t => (t === null || t === undefined ? 3 : toolCfg(t).d / 2);
const toolName = t => {
  if (t === null || t === undefined) return "нет";
  const c = toolCfg(t);
  return `${TOOL_TYPES[c.type]} Ø${N.fnum(c.d)}${c.name ? " " + c.name : ""}`;
};
const speedFactor = v => 10 ** (-2 + 4 * Number(v) / 100);
const fmtFactor = f => f >= 10 ? `×${f.toFixed(0)}` : f >= 1 ? `×${f.toFixed(1)}` : `×${f.toFixed(2)}`;

// ------------------------------------------------------------------ состояние
const S = {
  text: "", lines: [""], name: "", crlf: true, dirty: false, res: N.parse("", cfg), cur: 0,
  undo: [], redo: [], found: new Set(), view: "code", dataTab: "tools", codeCursor: {},
  sim: null, simSeg: 0, simT: 0, partial: false, playing: false, last3d: 0, lastFind: "",
};
const wide = () => window.matchMedia("(min-width: 900px)").matches;

// ------------------------------------------------------------------ сообщения и окна
let toastTimer = null;
function toast(msg, ms = 2600) {
  const t = $("toast"); t.textContent = msg; t.classList.remove("hidden");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.add("hidden"), ms);
}
function status(msg) { $("status").textContent = msg; }
let modalClose = null;
function openModal(html, onClose) {
  $("sheet").innerHTML = html; $("modal").classList.remove("hidden"); modalClose = onClose || null;
  $("sheet").scrollTop = 0;
  return $("sheet");
}
function closeModal() { $("modal").classList.add("hidden"); $("sheet").innerHTML = ""; const f = modalClose; modalClose = null; if (f) f(); }
$("modal").addEventListener("click", e => { if (e.target === $("modal")) closeModal(); });
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function ask(title, msg, buttons) {
  return new Promise(res => {
    const sh = openModal(`<h3>${esc(title)}</h3><div style="white-space:pre-line">${esc(msg)}</div><div class="btns">${buttons.map((b, i) =>
      `<button data-i="${i}" class="${i === buttons.length - 1 ? "primary" : ""}">${esc(b)}</button>`).join("")}</div>`, () => res(null));
    sh.querySelectorAll(".btns button").forEach(b => b.onclick = () => { modalClose = null; closeModal(); res(Number(b.dataset.i)); });
  });
}
function prompt2(title, label, value = "", type = "text") {
  return new Promise(res => {
    const sh = openModal(`<h3>${esc(title)}</h3><div class="form"><span>${esc(label)}</span><input id="pIn" type="${type}" value="${esc(value)}" style="width:170px"></div>
      <div class="btns"><button id="pNo">Отмена</button><button id="pOk" class="primary">OK</button></div>`, () => res(null));
    const inp = sh.querySelector("#pIn"); inp.focus(); inp.select();
    sh.querySelector("#pNo").onclick = () => { modalClose = null; closeModal(); res(null); };
    const ok = () => { const v = inp.value; modalClose = null; closeModal(); res(v); };
    sh.querySelector("#pOk").onclick = ok;
    inp.onkeydown = e => { if (e.key === "Enter") ok(); };
  });
}

// ------------------------------------------------------------------ текст программы
function setText(text, { undoable = true, keepView = true } = {}) {
  if (undoable && text !== S.text) { S.undo.push(S.text); if (S.undo.length > 40) S.undo.shift(); S.redo = []; }
  if (undoable && text !== S.text) S.dirty = true;
  S.text = text;
  S.lines = text.split("\n");
  reparse(keepView);
}
function title() { $("fname").textContent = (S.dirty ? "* " : "") + (S.name || "без имени"); }

function reparse(keepView = true) {
  stopPlay(true);
  S.res = N.parse(S.text, cfg);
  S.cur = Math.min(S.cur, S.lines.length - 1);
  title();
  $("codeSpacer").style.height = (S.lines.length * ROWH) + "px";
  renderRows(true);
  view2d.setResult(S.res);
  if (!keepView || !view2d._fitted) { view2d._fitted = view2d.el.clientWidth > 50; view2d.fit(); }
  buildFilters();
  buildLegend();
  buildSim();
  fillData();
  onCursor();
  const total = S.res.blocks.reduce((a, b) => a + b.time, 0);
  const nt = [...S.res.tools.keys()].filter(t => t !== null).length;
  status(`Строк: ${S.lines.length}   Смен инстр.: ${S.res.changes.length}   Инстр.: ${nt}   Замечаний: ${S.res.warnings.length}   Время ≈ ${N.fmtTime(total)}`);
  document.querySelector('#dataSeg [data-d=checks]').textContent = S.res.warnings.length ? `Проверки (${S.res.warnings.length})` : "Проверки";
}

// ------------------------------------------------------------------ код (виртуальный список)
const RX_HL = /\([^)]*\)|;.*$|([GMT])\s*[-+]?\d+\.?\d*|([FS])\s*[-+]?\d*\.?\d+/gi;
function highlight(line) {
  let out = "", last = 0;
  line.replace(RX_HL, (m, gmt, fs, off) => {
    out += esc(line.slice(last, off));
    const cls = m[0] === "(" || m[0] === ";" ? "hC" : gmt ? "h" + gmt.toUpperCase() : "hF";
    out += `<span class="${cls}">${esc(m)}</span>`;
    last = off + m.length; return m;
  });
  return out + esc(line.slice(last));
}
function gutterText(i) {
  const st = S.res.states[i];
  if (!st) return String(i + 1).padStart(5);
  const t = st.tool !== null ? "T" + st.tool : "--";
  const fv = st.f ? "F" + N.fnum(st.f) : "";
  return `${String(i + 1).padStart(5)}${st.change ? "►" : " "}${t.padEnd(4)}${N.motionName(st.motion).padEnd(4)}${fv}`;
}
let rowsFirst = -1, rowsLast = -1;
function renderRows(force = false) {
  const sc = $("codeScroll"), h = sc.clientHeight || 400;
  const first = Math.max(0, Math.floor(sc.scrollTop / ROWH) - 8);
  const last = Math.min(S.lines.length - 1, Math.ceil((sc.scrollTop + h) / ROWH) + 8);
  if (!force && first === rowsFirst && last === rowsLast) return;
  rowsFirst = first; rowsLast = last;
  const parts = [];
  for (let i = first; i <= last; i++) {
    const st = S.res.states[i];
    const t = st ? st.tool : null;
    const col = N.toolColor(t);
    const bg = cfg.tint_lines && t !== null ? `background:${N.tint(col, 0.9)}` : "";
    const cls = ["row", st && st.change ? "chg" : "", i === S.cur ? "cur" : "", S.found.has(i) ? "found" : ""].join(" ");
    parts.push(`<div class="${cls}" data-i="${i}"><span class="g" style="color:${col};background:${N.tint(col, 0.9)}">${gutterText(i)}</span><span class="c" style="${bg}">${highlight(S.lines[i]) || " "}</span></div>`);
  }
  const rows = $("codeRows");
  rows.style.top = (first * ROWH) + "px";
  rows.innerHTML = parts.join("");
}
$("codeScroll").addEventListener("scroll", () => renderRows());
let lastTapRow = { i: -1, t: 0 };
$("codeRows").addEventListener("click", e => {
  const r = e.target.closest(".row"); if (!r) return;
  const i = Number(r.dataset.i), now = performance.now();
  if (lastTapRow.i === i && now - lastTapRow.t < 400) { editLine(i); lastTapRow.i = -1; return; }
  lastTapRow = { i, t: now };
  setCur(i, false);
});
function setCur(i, scroll = true) {
  S.cur = Math.max(0, Math.min(i, S.lines.length - 1));
  if (scroll) {
    const sc = $("codeScroll"), y = S.cur * ROWH;
    if (y < sc.scrollTop || y > sc.scrollTop + sc.clientHeight - ROWH * 2) sc.scrollTop = Math.max(0, y - sc.clientHeight / 3);
  }
  renderRows(true);
  onCursor();
}

function stateRows(st, i) {
  const sp = { 3: "M03 вращение ↻", 4: "M04 вращение ↺", 5: "M05 стоп" }[st.sp];
  let blk = "—";
  S.res.blocks.forEach((b, n) => { if (b.start <= i && i <= b.end) blk = `№${n + 1}: ${b.start + 1}–${b.end + 1}`; });
  const rows = [["Строка", i + 1], ["Инструмент", (st.tool !== null ? "T" + st.tool : "не выбран") + (st.tool !== null ? " " + toolName(st.tool) : "")],
    ["Движение", N.motionName(st.motion) + " " + (N.CODE_INFO[N.motionName(st.motion)] || "")], ["Координаты", st.absl ? "G90 абс." : "G91 отн."],
    ["Коррекция", { 40: "G40 нет", 41: "G41 слева", 42: "G42 справа" }[st.comp] || ""], ["Сист. коорд.", `G${st.wcs} G${st.plane} ${st.units === 21 ? "мм" : "дюйм"}`],
    ["Подача F", st.f ? N.fnum(st.f) : "не задана"], ["Обороты S", st.s ? N.fnum(st.s) : "—"], ["Шпиндель", sp],
    ["Позиция", `X${N.fnum(st.x)} Y${N.fnum(st.y)} Z${N.fnum(st.z)}`], ["Коды строки", st.codes.join(" ") || "—"], ["Участок", blk]];
  return rows.map(([a, b]) => `<span>${esc(a)}:</span><b>${esc(b)}</b>`).join("");
}
function onCursor() {
  const i = S.cur, st = S.res.states[i];
  if (!st) return;
  $("stateGrid").innerHTML = stateRows(st, i);
  if (!S.playing) {
    updateInfo(st, i);
    view2d.sel = i;
    view2d.pos = st.tool !== null ? { x: st.x, y: st.y, z: st.z, tool: st.tool } : null;
    view2d.draw();
    if (v3d && !S.partial) {
      v3d.setToolMarker(st.tool !== null ? { x: st.x, y: st.y, z: st.z, r: toolRadius(st.tool), tool: st.tool } : null);
    }
  }
}
function updateInfo(st, line, pos) {
  const t = st.tool, col = N.toolColor(t);
  const chip = $("chip"); chip.textContent = t !== null ? "T" + t : "нет T"; chip.style.background = col;
  const [x, y, z] = pos || [st.x, st.y, st.z];
  const mode = { 0: "холостой", 1: "рез", 2: "дуга ↻", 3: "дуга ↺" }[st.motion] || "сверление";
  $("info1").textContent = `${t !== null ? toolName(t) : "инструмент не выбран"}  ${N.motionName(st.motion)} ${mode}`;
  $("info1").style.color = N.tint(col, 0.55);
  const sp = { 3: "M03", 4: "M04", 5: "M05 стоп" }[st.sp];
  $("info2").textContent = `F${st.f ? N.fnum(st.f) : "—"} S${st.s ? N.fnum(st.s) : "—"} ${sp}  X${x.toFixed(1)} Y${y.toFixed(1)} Z${z.toFixed(2)}  стр.${line + 1}`;
}
function buildLegend() {
  const tools = [...new Set(S.res.segs.map(s => s.tool).filter(t => t !== null))].sort((a, b) => a - b);
  $("legend").innerHTML = tools.map(t => `<span style="background:${N.toolColor(t)}">T${t} Ø${N.fnum(toolCfg(t).d)}</span>`).join("");
}

// ---------- правка строк
function editLine(i) {
  const sh = openModal(`<h3>Строка ${i + 1}</h3>
    <input id="eIn" style="width:100%;font:15px monospace" value="${esc(S.lines[i])}" autocapitalize="characters" autocomplete="off">
    <div class="btns"><button id="eDel">Удалить строку</button><button id="eIns">+ Строка ниже</button><button id="eNo">Отмена</button><button id="eOk" class="primary">Сохранить</button></div>`);
  const inp = sh.querySelector("#eIn"); inp.focus();
  const apply = (fn) => { const L = S.lines.slice(); fn(L); closeModal(); setText(L.join("\n")); };
  sh.querySelector("#eOk").onclick = () => apply(L => { L[i] = inp.value; });
  inp.onkeydown = e => { if (e.key === "Enter") sh.querySelector("#eOk").click(); };
  sh.querySelector("#eIns").onclick = () => { apply(L => { L[i] = inp.value; L.splice(i + 1, 0, ""); }); setCur(i + 1); editLine(i + 1); };
  sh.querySelector("#eDel").onclick = () => { if (S.lines.length > 1) apply(L => { L.splice(i, 1); }); };
  sh.querySelector("#eNo").onclick = closeModal;
}
$("cEdit").onclick = () => editLine(S.cur);
$("cText").onclick = () => {
  const sh = openModal(`<h3>Весь текст программы</h3><textarea class="full" id="tAll" spellcheck="false" autocapitalize="characters"></textarea>
    <div class="btns"><button id="tNo">Отмена</button><button id="tOk" class="primary">Готово</button></div>`);
  const ta = sh.querySelector("#tAll"); ta.value = S.text;
  const pos = S.lines.slice(0, S.cur).join("\n").length + (S.cur ? 1 : 0);
  ta.focus(); ta.setSelectionRange(pos, pos);
  ta.scrollTop = Math.max(0, S.cur * 17 - 100);
  sh.querySelector("#tNo").onclick = closeModal;
  sh.querySelector("#tOk").onclick = () => { const v = ta.value.replace(/\r\n?/g, "\n"); closeModal(); setText(v); };
};
$("cUndo").onclick = () => { if (!S.undo.length) return toast("Нечего отменять"); S.redo.push(S.text); S.text = S.undo.pop(); S.lines = S.text.split("\n"); S.dirty = true; reparse(); };
$("cRedo").onclick = () => { if (!S.redo.length) return toast("Нечего повторять"); S.undo.push(S.text); S.text = S.redo.pop(); S.lines = S.text.split("\n"); S.dirty = true; reparse(); };
$("cTint").checked = !!cfg.tint_lines;
$("cTint").onchange = () => { cfg.tint_lines = $("cTint").checked; saveCfg(); renderRows(true); };

// ---------- поиск и переход
$("cFind").onclick = () => { $("findBar").classList.toggle("hidden"); if (!$("findBar").classList.contains("hidden")) $("findIn").focus(); };
$("findClose").onclick = () => { $("findBar").classList.add("hidden"); S.found.clear(); renderRows(true); };
function findNext() {
  const q = $("findIn").value.trim().toUpperCase(); if (!q) return;
  const n = S.lines.length;
  for (let k = 1; k <= n; k++) {
    const i = (S.cur + k) % n;
    if (S.lines[i].toUpperCase().includes(q)) { setCur(i); return; }
  }
  toast(`«${q}» не найдено`);
}
$("findNext").onclick = findNext;
$("findIn").onkeydown = e => { if (e.key === "Enter") findNext(); };
$("findAll").onclick = () => {
  const q = $("findIn").value.trim().toUpperCase(); S.found.clear(); if (!q) return renderRows(true);
  S.lines.forEach((l, i) => { if (l.toUpperCase().includes(q)) S.found.add(i); });
  renderRows(true); toast(`«${q}»: найдено ${S.found.size}`);
};
$("cGoto").onclick = async () => {
  const v = await prompt2("Переход", "Номер строки:", "", "number");
  if (v) { setCur(Number(v) - 1); showView("code"); }
};

// ------------------------------------------------------------------ 2D
const view2d = new View2D($("cv2d"), {
  toolRadius,
  onTap: info => { setCur(info.line); toast(`X ${N.fnum(Math.round(info.x * 1000) / 1000)}  Y ${N.fnum(Math.round(info.y * 1000) / 1000)}  Z ${N.fnum(Math.round(info.z * 1000) / 1000)}\nT${info.tool ?? "—"}  строка ${info.line + 1}`, 1800); },
  onRuler: r => status(`Линейка: L = ${r.L.toFixed(2)} мм   ΔX ${r.dx.toFixed(2)}   ΔY ${r.dy.toFixed(2)}   ΔZ ${r.dz.toFixed(2)}   угол ${r.ang.toFixed(1)}°`),
});
function buildFilters() {
  const bar = $("bar2d");
  const tools = [...new Set(S.res.segs.map(s => s.tool))].sort((a, b) => (a === null) - (b === null) || (a ?? 0) - (b ?? 0));
  bar.innerHTML = tools.map(t => `<label class="chk"><input type="checkbox" data-t="${t}" ${view2d.filter[t] === false ? "" : "checked"}>
      <span style="background:${N.toolColor(t)};width:12px;height:12px;display:inline-block;border-radius:2px"></span>${t !== null ? "T" + t : "без T"}</label>`).join("") +
    `<label class="chk"><input type="checkbox" id="f2Rapid" ${view2d.showRapid ? "checked" : ""}>Холостые</label>
     <label class="chk"><input type="checkbox" id="f2Ruler" ${view2d.rulerMode ? "checked" : ""}>📏 Линейка</label>
     <button id="f2All">Все</button><button id="f2Fit">Вписать</button>`;
  bar.querySelectorAll("input[data-t]").forEach(cb => cb.onchange = () => {
    const t = cb.dataset.t === "null" ? null : Number(cb.dataset.t); view2d.filter[t] = cb.checked; view2d.draw();
  });
  $("f2Rapid").onchange = () => { view2d.showRapid = $("f2Rapid").checked; view2d.draw(); };
  $("f2Ruler").onchange = () => { view2d.rulerMode = $("f2Ruler").checked; view2d.clearRuler(); if (view2d.rulerMode) toast("Линейка: коснитесь двух точек"); };
  $("f2All").onclick = () => { view2d.filter = {}; view2d.showRapid = true; buildFilters(); view2d.draw(); };
  $("f2Fit").onclick = () => view2d.fit();
}

// ------------------------------------------------------------------ 3D
let v3d = null, StockSim = null;
async function init3d() {
  try {
    const m = await import("./view3d.js");
    StockSim = m.StockSim;
    const test = document.createElement("canvas");
    if (!(test.getContext("webgl2") || test.getContext("webgl"))) throw new Error("no webgl");
    v3d = new m.Viewer3D($("cv3d"), { toolRadius, onTap: tap3d });
    v3d.onHover = (info, sx, sy) => showTip3(info, sx, sy);
  } catch (e) {
    v3d = null; $("no3d").classList.remove("hidden"); console.log("3D:", e);
  }
}
function showTip3(info, sx, sy) {
  const tip = $("tip3");
  if (v3d) { v3d.hover = info; v3d.refresh(); }
  if (!info) { tip.classList.add("hidden"); return; }
  tip.textContent = `X=${N.fnum(Math.round(info.x * 1000) / 1000)}\nY=${N.fnum(Math.round(info.y * 1000) / 1000)}\nZ=${N.fnum(Math.round(info.z * 1000) / 1000)}\nT${info.tool ?? "—"}  стр.${info.line + 1}`;
  tip.style.borderColor = N.toolColor(info.tool);
  const w = $("cv3d").clientWidth;
  tip.style.left = (sx + 150 < w ? sx + 16 : sx - 140) + "px";
  tip.style.top = (sy > 90 ? sy - 82 : sy + 16) + "px";
  tip.classList.remove("hidden");
}
function tap3d(info, sx, sy) {
  if (!v3d) return;
  if (v3d.rulerMode) {
    if (!info) return;
    if (v3d.ruler.length >= 2) v3d.ruler = [];
    v3d.ruler.push([info.x, info.y, info.z]);
    showTip3(info, sx, sy);
    const r = v3d.ruler;
    if (r.length === 2) {
      const [a, b] = r, dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
      const L = Math.hypot(dx, dy), L3 = Math.hypot(dx, dy, dz);
      $("ruler3").textContent = `L = ${L.toFixed(2)} мм  (в 3D ${L3.toFixed(2)})\nΔX ${dx.toFixed(2)}  ΔY ${dy.toFixed(2)}  ΔZ ${dz.toFixed(2)}\nугол ${(Math.atan2(dy, dx) * 180 / Math.PI).toFixed(1)}°`;
      $("ruler3").classList.remove("hidden");
      status(`Линейка 3D: L = ${L.toFixed(2)} мм   ΔX ${dx.toFixed(2)}   ΔY ${dy.toFixed(2)}   ΔZ ${dz.toFixed(2)}`);
    } else $("ruler3").classList.add("hidden");
    v3d.refresh();
    return;
  }
  showTip3(info, sx, sy);
  if (info) { setCur(info.line); updateInfo(S.res.states[info.line], info.line, [info.x, info.y, info.z]); }
}
document.querySelectorAll("#bar3dViews [data-v]").forEach(b => b.onclick = () => v3d && v3d.setView(b.dataset.v));
$("v3Fit").onclick = () => v3d && v3d.fit();
$("o3Ortho").onchange = () => { if (v3d) { v3d.ortho = $("o3Ortho").checked; v3d.refresh(); } };
$("o3Paths").onchange = () => { if (v3d) { v3d.showPaths = $("o3Paths").checked; v3d.refresh(); } };
$("o3Stock").onchange = () => { if (v3d) { v3d.showStock = $("o3Stock").checked; v3d.refresh(); } };
$("o3Ruler").onchange = () => {
  if (!v3d) return;
  v3d.rulerMode = $("o3Ruler").checked; v3d.ruler = []; $("ruler3").classList.add("hidden"); v3d.refresh();
  if (v3d.rulerMode) toast("Линейка: коснитесь двух точек траектории");
};

function buildSim() {
  const [top, bot] = N.stockLevels(cfg);
  const cb = S.res.cutBounds;
  let x0, y0, x1, y1;
  if (cfg.stock_auto) {
    if (cb) { x0 = Math.min(0, cb[0] - 10); y0 = Math.min(0, cb[1] - 10); x1 = Math.ceil((cb[2] + 10) / 10) * 10; y1 = Math.ceil((cb[3] + 10) / 10) * 10; }
    else { x0 = 0; y0 = 0; x1 = 1000; y1 = 1000; }
  } else { x0 = 0; y0 = 0; x1 = Number(cfg.stock_x) || 2750; y1 = Number(cfg.stock_y) || 1830; }
  S.sim = StockSim ? new StockSim(x0, y0, x1, y1, top, bot, Number(cfg.sim_cell) || 3) : null;
  S.simSeg = 0; S.simT = 0;
  if (v3d) {
    v3d.toolMarker = null;
    v3d.setSim(S.sim);
    v3d.setPaths(S.res.segs);
    $("ruler3").classList.add("hidden"); $("tip3").classList.add("hidden");
  }
}

// ------------------------------------------------------------------ проигрывание
const segLen = s => s.kind === "drill" ? Math.max(s.len, 1e-6) : Math.max(s.pts.reduce((a, p, k) => k ? a + Math.hypot(p[0] - s.pts[k - 1][0], p[1] - s.pts[k - 1][1], p[2] - s.pts[k - 1][2]) : 0, 0), 1e-6);
function segSlice(s, s0, s1) {
  if (s.kind === "drill") {
    const [[x, y, za], [, , zb]] = s.pts, half = s.len / 2;
    const zat = v => za + (zb - za) * (half > 0 ? Math.min(v, half) / half : 1);
    return [[x, y, zat(s0)], [x, y, zat(s1)]];
  }
  const out = []; let acc = 0;
  for (let k = 0; k + 1 < s.pts.length; k++) {
    const a = s.pts[k], b = s.pts[k + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    if (L <= 1e-12) continue;
    const e0 = acc, e1 = acc + L;
    if (e1 >= s0 && e0 <= s1) {
      const ta = Math.max(0, (s0 - e0) / L), tb = Math.min(1, (s1 - e0) / L);
      const pa = [0, 1, 2].map(i => a[i] + (b[i] - a[i]) * ta), pb = [0, 1, 2].map(i => a[i] + (b[i] - a[i]) * tb);
      if (!out.length) out.push(pa);
      out.push(pb);
    }
    acc = e1; if (acc > s1) break;
  }
  return out;
}
function segCut(s, s0, s1) {
  if (!S.sim || s1 <= s0) return;
  const sub = segSlice(s, s0, s1);
  if (sub.length >= 2) S.sim.cutPolyline(sub, toolRadius(s.tool), s.tool ?? 0);
}
function restartAtLine(line) {
  if (S.sim) S.sim.reset();
  if (v3d && v3d.stock) v3d.stock.full = true;
  const segs = S.res.segs; let n = 0;
  while (n < segs.length && segs[n].line < line) { segCut(segs[n], 0, segLen(segs[n])); n++; }
  S.simSeg = n; S.simT = 0; S.partial = true;
  view2d.limit = n;
}
function showPlayPos(s, dist) {
  const sub = dist > 0 ? segSlice(s, Math.max(0, dist - 1e-6), dist) : null;
  const [x, y, z] = sub && sub.length ? sub[sub.length - 1] : s.pts[0];
  if (S.cur !== s.line) setCur(s.line);
  updateInfo(S.res.states[s.line], s.line, [x, y, z]);
  view2d.pos = { x, y, z, tool: s.tool }; view2d.sel = null; view2d.limit = S.simSeg; view2d.draw();
  if (v3d) {
    v3d.toolMarker = { x, y, z, r: toolRadius(s.tool), tool: s.tool ?? 0 };
    const now = performance.now();
    if (now - S.last3d > 120 || !S.playing) { S.last3d = now; v3d.refresh(); }
  }
}
let playRaf = null, tickT = 0;
function playLoop() {
  if (!S.playing) return;
  const now = performance.now(), dt = Math.min((now - tickT) / 1000, 0.2); tickT = now;
  let budget = dt * speedFactor($("pSpeed").value);
  const segs = S.res.segs, t0 = performance.now();
  let s = null;
  while (S.simSeg < segs.length && budget > 0) {
    s = segs[S.simSeg];
    const L = segLen(s), v = Math.max(s.feed, 1) / 60, need = (L - S.simT) / v;
    if (need <= budget) { segCut(s, S.simT, L); budget -= need; S.simSeg++; S.simT = 0; }
    else { const nt = S.simT + budget * v; segCut(s, S.simT, nt); S.simT = nt; budget = 0; }
    if (performance.now() - t0 > 30) break;
  }
  if (s) showPlayPos(s, S.simT > 0 ? S.simT : segLen(s));
  if (S.simSeg >= segs.length) {
    S.playing = false; S.partial = false; $("pPlay").textContent = "▶"; view2d.limit = null; view2d.draw();
    if (v3d) v3d.refresh();
    status("Проигрывание завершено"); return;
  }
  playRaf = requestAnimationFrame(playLoop);
}
function play() {
  if (!S.res.segs.length) return;
  if (S.playing) { S.playing = false; $("pPlay").textContent = "▶"; cancelAnimationFrame(playRaf); return; }
  if (!S.partial) { let start = S.cur; if (start >= S.lines.length - 1) start = 0; restartAtLine(start); }
  S.playing = true; $("pPlay").textContent = "⏸"; tickT = performance.now();
  playRaf = requestAnimationFrame(playLoop);
}
function step() {
  if (!S.res.segs.length) return;
  if (S.playing) play();
  if (!S.partial) restartAtLine(S.cur);
  const segs = S.res.segs;
  if (S.simSeg >= segs.length) return;
  const line = segs[S.simSeg].line;
  segCut(segs[S.simSeg], S.simT, segLen(segs[S.simSeg])); S.simSeg++; S.simT = 0;
  while (S.simSeg < segs.length && segs[S.simSeg].line === line) { const s = segs[S.simSeg]; segCut(s, 0, segLen(s)); S.simSeg++; }
  const s = segs[S.simSeg - 1];
  showPlayPos(s, segLen(s));
  if (v3d) v3d.refresh();
}
function stopPlay(silent = false) {
  const was = S.partial || S.playing;
  S.playing = false; cancelAnimationFrame(playRaf); S.partial = false;
  $("pPlay").textContent = "▶";
  view2d.limit = null;
  if (!silent && was) {
    if (S.sim) S.sim.reset();
    if (v3d) { if (v3d.stock) v3d.stock.full = true; v3d.toolMarker = null; v3d.refresh(); }
    onCursor();
  }
  view2d.draw();
}
function result() {
  stopPlay(true);
  if (!S.res.segs.length) return;
  restartAtLine(1e12);
  S.partial = false; view2d.limit = null; view2d.draw();
  if (v3d) { v3d.toolMarker = null; v3d.refresh(); }
  if (!wide() || S.view !== "3d") showView("3d");
  status("Показан результат обработки всей программы");
}
$("pPlay").onclick = play; $("pStep").onclick = step; $("pStop").onclick = () => stopPlay(false); $("pRes").onclick = result;
$("pSpeed").value = cfg.speed;
const speedLbl = () => { $("pSpeedLbl").textContent = fmtFactor(speedFactor($("pSpeed").value)); };
$("pSpeed").oninput = () => { speedLbl(); cfg.speed = Number($("pSpeed").value); saveCfg(); };
speedLbl();

// ------------------------------------------------------------------ данные: инструменты, коды, проверки
document.querySelectorAll("#dataSeg button").forEach(b => b.onclick = () => {
  S.dataTab = b.dataset.d; document.querySelectorAll("#dataSeg button").forEach(x => x.classList.toggle("on", x === b)); fillData();
});
function fillData() {
  const R = S.res, body = $("dataBody");
  if (S.dataTab === "tools") {
    const counts = new Map(); R.blocks.forEach(b => counts.set(b.tool, (counts.get(b.tool) || 0) + 1));
    const tr = (b, extra) => `style="color:${N.toolColor(b.tool)};background:${N.tint(N.toolColor(b.tool), 0.9)}" ${extra}`;
    let h = `<h4>Смены инструмента — касание: перейти к строке</h4><div class="hscroll"><table><tr><th>№</th><th>Инстр.</th><th>Строки</th><th>Рез, м</th><th>Холост., м</th><th>Отв.</th><th>Время</th></tr>`;
    R.blocks.forEach((b, n) => {
      h += `<tr class="tap" data-line="${b.start}" ${tr(b, "")}><td>${n + 1}</td><td><b>${b.tool !== null ? "T" + b.tool : "—"}</b></td><td>${b.start + 1}–${b.end + 1}</td>
        <td>${(b.cut / 1000).toFixed(2)}</td><td>${(b.rapid / 1000).toFixed(2)}</td><td>${b.drills || ""}</td><td>${N.fmtTime(b.time)}</td></tr>`;
    });
    h += `</table></div><h4>Итого по инструментам — касание: показать только его на плане</h4><div class="hscroll"><table><tr><th>Инстр.</th><th>Название</th><th>Участков</th><th>Рез, м</th><th>Холост., м</th><th>Отв.</th><th>Время</th></tr>`;
    [...R.tools.entries()].sort((a, b) => (a[0] === null) - (b[0] === null) || (a[0] ?? 0) - (b[0] ?? 0)).forEach(([t, b]) => {
      h += `<tr class="tap" data-solo="${t}" ${tr({ tool: t }, "")}><td><b>${t !== null ? "T" + t : "—"}</b></td><td class="l">${esc(toolName(t))}</td><td>${counts.get(t) || 0}</td>
        <td>${(b.cut / 1000).toFixed(2)}</td><td>${(b.rapid / 1000).toFixed(2)}</td><td>${b.drills || ""}</td><td>${N.fmtTime(b.time)}</td></tr>`;
    });
    body.innerHTML = h + "</table></div>";
  } else if (S.dataTab === "codes") {
    const spmap = N.parseSpmap(cfg.spindle_codes);
    const key = c => { const m = c.match(/([A-Z])(\d+(?:\.\d+)?)/); return m ? ["GMT".indexOf(m[1]) * 1e6 + parseFloat(m[2])] : [9e9]; };
    let h = `<h4>Касание — к следующей строке с этим кодом</h4><table><tr><th>Код</th><th>Раз</th><th>Первая</th><th>Значение</th></tr>`;
    Object.keys(R.codes).sort((a, b) => key(a) - key(b)).forEach(code => {
      let info = N.CODE_INFO[code] || "";
      if (code.startsWith("T")) { const t = Number(code.slice(1)); info = "Выбор инструмента — " + toolName(t); }
      if (code in spmap) info = `Выбор шпинделя → T${spmap[code]}`;
      h += `<tr class="tap" data-code="${code}"><td><b>${code}</b></td><td>${R.codes[code].length}</td><td>${R.codes[code][0] + 1}</td><td class="l">${esc(info)}</td></tr>`;
    });
    body.innerHTML = h + "</table>";
  } else {
    if (!R.warnings.length) { body.innerHTML = `<h4>Замечаний нет</h4>`; return; }
    body.innerHTML = `<h4>Касание — перейти к строке</h4><table><tr><th>Строка</th><th>Замечание</th></tr>` +
      R.warnings.map(([ln, msg]) => `<tr class="tap" data-line="${ln}"><td>${ln + 1}</td><td class="l">${esc(msg)}</td></tr>`).join("") + "</table>";
  }
}
$("dataBody").addEventListener("click", e => {
  const tr = e.target.closest("tr.tap"); if (!tr) return;
  if (tr.dataset.line !== undefined) { setCur(Number(tr.dataset.line)); if (!wide()) showView("code"); }
  else if (tr.dataset.solo !== undefined) {
    const key = tr.dataset.solo === "null" ? null : Number(tr.dataset.solo);
    const tools = new Set(S.res.segs.map(s => s.tool)); view2d.filter = {};
    for (const t of tools) view2d.filter[t] = t === key;
    buildFilters(); view2d.draw(); showView("2d");
  } else if (tr.dataset.code) {
    const code = tr.dataset.code, lines = S.res.codes[code];
    S.found = new Set(lines);
    const k = ((S.codeCursor[code] ?? -1) + 1) % lines.length; S.codeCursor[code] = k;
    setCur(lines[k]); toast(`${code}: ${k + 1} из ${lines.length} (строка ${lines[k] + 1})`, 1500);
    if (!wide()) showView("code");
  }
});

// ------------------------------------------------------------------ вкладки
function showView(v) {
  if (wide() && v === "code") v = S.view === "code" ? "2d" : S.view;
  S.view = v;
  const ids = { code: "vCode", "2d": "v2d", "3d": "v3d", data: "vData" };
  for (const [k, id] of Object.entries(ids)) $(id).classList.toggle("show", k === v);
  document.querySelectorAll("#tabs button").forEach(b => b.classList.toggle("on", b.dataset.t === v));
  if (v === "code") renderRows(true);
  if (v === "2d") { view2d.resize(); if (!view2d._fitted) { view2d._fitted = true; view2d.fit(); } }
  if (v === "3d" && v3d) { v3d.resize(); v3d.refresh(); }
}
document.querySelectorAll("#tabs button").forEach(b => b.onclick = () => showView(b.dataset.t));
window.addEventListener("resize", () => { renderRows(true); if (wide() && S.view === "code") showView("2d"); });

// ------------------------------------------------------------------ файлы
const bridge = window.AndroidBridge || null;
function decodeBytes(buf) {
  const u8 = new Uint8Array(buf);
  try { return new TextDecoder("utf-8", { fatal: true }).decode(u8); } catch (e) { /* не utf-8 */ }
  try { return new TextDecoder("windows-1251").decode(u8); } catch (e) { return new TextDecoder("latin1").decode(u8); }
}
async function loadProgram(name, text) {
  if (S.dirty) {
    const a = await ask("Корректор NC", "Есть несохранённые изменения. Открыть другой файл?", ["Отмена", "Открыть"]);
    if (a !== 1) return;
  }
  S.crlf = text.includes("\r\n");
  let t = text.replace(/\r\n?/g, "\n");
  if (t.endsWith("\n")) t = t.slice(0, -1);
  S.name = name; S.dirty = false; S.undo = []; S.redo = []; S.cur = 0; S.found.clear();
  view2d._fitted = false; view2d.filter = {};
  $("codeScroll").scrollTop = 0;
  setText(t, { undoable: false, keepView: false });
  S.dirty = false; title();
  if (v3d) v3d.fit();
  toast(`Открыт: ${name}\nстрок ${S.lines.length}`);
}
window.toastFromAndroid = msg => toast(msg, 3500);
window.KorrektorOpen = (name, b64) => {   // вызывается из Android при открытии файла извне
  const bin = atob(b64), u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  loadProgram(name || "program.nc", decodeBytes(u8.buffer));
};
$("bOpen").onclick = () => $("fileIn").click();
$("fileIn").onchange = async () => {
  const f = $("fileIn").files[0]; $("fileIn").value = "";
  if (!f) return;
  loadProgram(f.name, decodeBytes(await f.arrayBuffer()));
};
function outText() { return S.lines.join(S.crlf ? "\r\n" : "\n") + (S.crlf ? "\r\n" : "\n"); }
async function saveAs(name) {
  if (!name) return;
  const txt = outText();
  if (/[А-Яа-яЁё]/.test(txt) || /[А-Яа-яЁё]/.test(name))
    toast("Внимание: в программе или имени файла есть кириллица — станок может не прочитать файл.", 4000);
  try {
    if (bridge && bridge.saveFile) {
      const where = bridge.saveFile(name, txt);
      S.name = name; S.dirty = false; title();
      toast(`Сохранено:\n${where}`, 3500); return;
    }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([txt], { type: "text/plain" })); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    S.name = name; S.dirty = false; title(); toast(`Сохранено: ${name}`);
  } catch (e) { toast("Не удалось сохранить: " + e.message, 4000); }
}
$("bSave").onclick = () => S.name ? saveAs(S.name) : saveAsDialog();
async function saveAsDialog() {
  const v = await prompt2("Сохранить как", "Имя файла:", S.name || "program.nc");
  if (v) saveAs(v.trim());
}
async function shareFile() {
  const name = S.name || "program.nc", txt = outText();
  if (bridge && bridge.shareFile) { bridge.shareFile(name, txt); return; }
  try {
    const file = new File([txt], name, { type: "text/plain" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: name }); return; }
  } catch (e) { /* отменено */ }
  toast("Отправка файла недоступна — используйте «Сохранить»");
}

// ------------------------------------------------------------------ меню
$("bMenu").onclick = () => {
  const sh = openModal(`<h3>Меню</h3><div class="menu">
    <button data-a="saveas">💾 Сохранить как…</button>
    <button data-a="share">📤 Отправить файл (Telegram и др.)</button>
    <button data-a="modes">✎ Редактор режимов (заход, S, F)</button>
    <button data-a="settings">⚙ Настройки (инструменты, лист, 3D)</button>
    <button data-a="find">🔍 Найти</button>
    <button data-a="goto">№ Перейти к строке</button>
    <button data-a="sample">📄 Открыть пример программы</button>
    <button data-a="about">ⓘ О программе</button></div>`);
  sh.querySelectorAll("button[data-a]").forEach(b => b.onclick = () => {
    closeModal();
    ({
      saveas: saveAsDialog, share: shareFile, modes: openModes, settings: openSettings,
      find: () => { showView("code"); $("findBar").classList.remove("hidden"); $("findIn").focus(); },
      goto: () => $("cGoto").onclick(), sample: () => loadProgram("TEST_1.NC", SAMPLE),
      about: () => ask("Корректор NC", "Мобильная версия Корректора NC.\nПросмотр и правка УП, 2D/3D, проигрывание,\nредактор режимов, линейка.", ["OK"]),
    })[b.dataset.a]();
  });
};

// ------------------------------------------------------------------ настройки
function openSettings(tab = "tools") {
  const tools = [...new Set([...Object.keys(cfg.tools).map(Number).filter(n => n > 0), ...[...S.res.tools.keys()].filter(t => t !== null), 1, 2, 3])].sort((a, b) => a - b);
  const toolRow = t => { const c = toolCfg(t); return `<tr data-t="${t}"><td class="tn" style="color:${N.toolColor(t)}">T${t}</td>
    <td><select>${Object.entries(TOOL_TYPES).map(([k, v]) => `<option value="${k}" ${c.type === k ? "selected" : ""}>${v}</option>`).join("")}</select></td>
    <td><input type="number" step="0.1" value="${c.d}"></td><td><input type="text" value="${esc(c.name)}" style="min-width:110px"></td></tr>`; };
  const sh = openModal(`<h3>Настройки</h3>
    <div class="tabsIn"><button data-p="tools">Инструменты</button><button data-p="stock">Лист и 3D</button><button data-p="gen">Общие</button></div>
    <div data-pane="tools"><div class="hint">Диаметр нужен для 3D (ширина реза, размер отверстий).</div>
      <div class="hscroll"><table class="rtable"><tr><th>T</th><th>Тип</th><th>Ø, мм</th><th>Название</th></tr><tbody id="sTools">${tools.map(toolRow).join("")}</tbody></table></div>
      <div class="btns" style="justify-content:flex-start"><input type="number" id="sNew" placeholder="№ T" style="width:70px"><button id="sAdd">+ Инструмент</button><button id="sImp">Импорт из библиотеки Раскроя…</button></div></div>
    <div data-pane="stock"><div class="form">
      <span>Толщина листа, мм</span><input type="number" id="sTh" value="${cfg.stock_thickness}">
      <span>Ноль Z</span><select id="sZ"><option value="top" ${cfg.z_zero === "top" ? "selected" : ""}>на верху листа</option><option value="table" ${cfg.z_zero === "table" ? "selected" : ""}>на столе</option></select>
      <span>Размер листа автоматически</span><input type="checkbox" id="sAuto" ${cfg.stock_auto ? "checked" : ""} style="width:22px;height:22px">
      <span>Лист по X, мм</span><input type="number" id="sX" value="${cfg.stock_x}">
      <span>Лист по Y, мм</span><input type="number" id="sY" value="${cfg.stock_y}">
      <span>Точность 3D, мм<br><span class="hint">меньше — точнее, но тяжелее для телефона</span></span><input type="number" step="0.5" id="sCell" value="${cfg.sim_cell}">
    </div></div>
    <div data-pane="gen"><div class="form">
      <span>Скорость холостых, мм/мин</span><input type="number" id="sRapid" value="${cfg.rapid_feed}">
      <span>Предельная глубина Z</span><input type="number" step="0.1" id="sDepth" value="${cfg.max_depth}">
      <span>Коды выбора шпинделя<br><span class="hint">напр. M31=1, M32=2</span></span><input type="text" id="sSp" value="${esc(cfg.spindle_codes)}">
    </div></div>
    <div class="btns"><button id="sNo">Отмена</button><button id="sOk" class="primary">OK</button></div>`);
  const panes = sh.querySelectorAll("[data-pane]"), tbs = sh.querySelectorAll(".tabsIn button");
  const showP = p => { panes.forEach(x => x.classList.toggle("hidden", x.dataset.pane !== p)); tbs.forEach(x => x.classList.toggle("on", x.dataset.p === p)); };
  tbs.forEach(b => b.onclick = () => showP(b.dataset.p)); showP(tab);
  const addRow = (t, info) => {
    let tr = sh.querySelector(`#sTools tr[data-t="${t}"]`);
    if (!tr) { sh.querySelector("#sTools").insertAdjacentHTML("beforeend", toolRow(t)); tr = sh.querySelector(`#sTools tr[data-t="${t}"]`); }
    if (info) { tr.querySelector("select").value = info.type; tr.querySelectorAll("input")[0].value = info.d; if (info.name) tr.querySelectorAll("input")[1].value = info.name; }
  };
  sh.querySelector("#sAdd").onclick = () => {
    const n = Number(sh.querySelector("#sNew").value);
    if (!(n > 0)) return toast("Введите номер инструмента");
    addRow(n, null); sh.querySelector("#sNew").value = "";
  };
  sh.querySelector("#sImp").onclick = () => {
    $("toolsIn").onchange = async () => {
      const f = $("toolsIn").files[0]; $("toolsIn").value = ""; if (!f) return;
      try {
        const got = N.importToolsJSON(JSON.parse(decodeBytes(await f.arrayBuffer())));
        const keys = Object.keys(got);
        if (!keys.length) return toast("В файле не найдено инструментов с диаметром", 3500);
        keys.forEach(k => addRow(Number(k), got[k]));
        toast("Загружено инструментов: " + keys.length + "\n" + keys.map(k => `T${k}: ${TOOL_TYPES[got[k].type]} Ø${N.fnum(got[k].d)} ${got[k].name}`).join("\n"), 4000);
      } catch (e) { toast("Не удалось прочитать файл: " + e.message, 4000); }
    };
    $("toolsIn").click();
  };
  sh.querySelector("#sNo").onclick = closeModal;
  sh.querySelector("#sOk").onclick = () => {
    const num = (id, def) => { const v = parseFloat(String(sh.querySelector(id).value).replace(",", ".")); return Number.isFinite(v) ? v : def; };
    const tools2 = {};
    for (const tr of sh.querySelectorAll("#sTools tr")) {
      const d = parseFloat(tr.querySelectorAll("input")[0].value.replace(",", "."));
      if (!(d > 0)) return toast(`T${tr.dataset.t}: проверьте диаметр`);
      tools2[tr.dataset.t] = { type: tr.querySelector("select").value, d, name: tr.querySelectorAll("input")[1].value.trim() };
    }
    Object.assign(cfg, {
      tools: tools2, stock_thickness: num("#sTh", 16), z_zero: sh.querySelector("#sZ").value, stock_auto: sh.querySelector("#sAuto").checked,
      stock_x: num("#sX", 2750), stock_y: num("#sY", 1830), sim_cell: Math.max(0.5, num("#sCell", 3)),
      rapid_feed: num("#sRapid", 30000), max_depth: num("#sDepth", -18), spindle_codes: sh.querySelector("#sSp").value.trim(),
    });
    saveCfg(); closeModal(); reparse();
  };
}

// ------------------------------------------------------------------ редактор режимов
function openModes() {
  const [zTop] = N.stockLevels(cfg);
  const spmap = N.parseSpmap(cfg.spindle_codes);
  const tools = [...new Set([...[...S.res.tools.keys()].filter(t => t !== null), ...Object.keys(cfg.edit_rules).map(Number).filter(n => n > 0)])].sort((a, b) => a - b);
  if (!tools.length) return toast("В программе нет инструментов (T)");
  const types = {}; tools.forEach(t => { types[t] = toolCfg(t).type; });
  const [, found] = N.transform(S.text, {}, zTop, 1, types, spmap);
  const sv = t => cfg.edit_rules[String(t)] || {};
  const v = x => (x === null || x === undefined || x === "") ? "" : N.fnum(Number(x));
  const sh = openModal(`<h3>Редактор режимов</h3>
    <div class="hint">Для каждого инструмента: как заходить в материал, обороты и подачи. Пустое поле или «Не менять» — как в программе.</div>
    ${tools.map(t => { const r = sv(t), dr = types[t] === "drill"; return `<div class="mcard" data-t="${t}">
      <div class="hd"><b style="color:${N.toolColor(t)}">T${t}</b><span>${esc(toolName(t))}</span><span class="hint" style="margin-left:auto">прямых врезаний: ${found[t]?.found || 0}</span></div>
      <div class="grid">
        <label class="wide">Заход в материал<select ${dr ? "disabled" : ""}>${Object.entries(N.ENTRY_NAMES).map(([k, n]) => `<option value="${k}" ${(dr ? "none" : (r.entry || "none")) === k ? "selected" : ""}>${n}</option>`).join("")}</select></label>
        <label>Угол, °<input type="number" step="0.5" inputmode="decimal" value="${v(r.angle ?? 5)}"></label>
        <label>Длина зигзага, мм<input type="number" inputmode="decimal" value="${v(r.zig ?? 50)}"></label>
        <label>Обороты S<input type="number" inputmode="decimal" value="${v(r.S)}"></label>
        <label>Подача реза F<input type="number" inputmode="decimal" value="${v(r.F)}"></label>
        <label>Подача захода F<input type="number" inputmode="decimal" value="${v(r.Fz)}"></label>
      </div></div>`; }).join("")}
    <div class="form" style="margin-top:10px"><span>Начинать наклон выше листа на, мм<br><span class="hint">верх листа Z${N.fnum(zTop)}</span></span><input type="number" step="0.5" id="mCl" value="${v(cfg.ramp_clear)}"></div>
    <p class="hint">Наклонное 3D — фреза опускается по наклону, идя по контуру; клин в начале дорезается. Для незамкнутого реза выполняется зигзагом.<br>
    Зигзаг — опускание вперёд-назад по началу контура, затем обычный рез.<br>Сверла (тип «Сверло» в Настройках) — только S и F.</p>
    <div class="btns"><button id="mReset">Сбросить</button><button id="mNo">Закрыть</button><button id="mOk" class="primary">Применить к программе</button></div>`);
  sh.querySelector("#mNo").onclick = closeModal;
  sh.querySelector("#mReset").onclick = () => sh.querySelectorAll(".mcard[data-t]").forEach(tr => {
    const sel = tr.querySelector("select"); sel.value = "none"; const ins = tr.querySelectorAll("input"); ins[2].value = ins[3].value = ins[4].value = "";
  });
  sh.querySelector("#mOk").onclick = () => {
    const rules = {}, store = {};
    for (const tr of sh.querySelectorAll(".mcard[data-t]")) {
      const t = Number(tr.dataset.t), ins = tr.querySelectorAll("input");
      const num = (k, name) => { const s = ins[k].value.trim().replace(",", "."); if (!s) return null; const x = Number(s); if (!(x > 0)) throw new Error(`T${t}: ${name} должно быть больше 0`); return x; };
      let rule;
      try { rule = { entry: tr.querySelector("select").value, angle: num(0, "угол") || 5, zig: num(1, "длина зигзага") || 50, S: num(2, "S"), F: num(3, "подача реза"), Fz: num(4, "подача захода") }; }
      catch (e) { return toast(e.message, 3500); }
      if (rule.angle < 0.5 || rule.angle > 45) return toast(`T${t}: угол должен быть от 0.5 до 45°`, 3500);
      store[String(t)] = rule;
      if (rule.entry !== "none" || rule.S || rule.F || rule.Fz) rules[t] = rule;
    }
    const clear = parseFloat(String(sh.querySelector("#mCl").value).replace(",", ".")) || 1;
    cfg.edit_rules = store; cfg.ramp_clear = clear; saveCfg();
    if (!Object.keys(rules).length) return toast("Ничего не задано — программа не изменена");
    const [nw, rep] = N.transform(S.text, rules, zTop, clear, types, spmap);
    if (nw === S.text) return toast("Изменений нет (программа уже такая)");
    closeModal();
    setText(nw);
    const lines = Object.keys(rep).sort((a, b) => a - b).map(t => {
      const r = rep[t], p = [];
      if (r.ramps) p.push(`заходов изменено ${r.ramps}`); if (r.skipped) p.push(`пропущено коротких ${r.skipped}`);
      if (r.S) p.push(`S изменено ${r.S}`); if (r.F) p.push(`F изменено ${r.F}`);
      return p.length ? `T${t}: ${p.join(", ")}` : "";
    }).filter(Boolean);
    ask("Программа изменена", lines.join("\n") + "\n\nПроверьте в 3D (■ или ▶).\nОтменить — ↶ на вкладке «Код».\nНе забудьте сохранить файл.", ["OK"]);
  };
}

// ------------------------------------------------------------------ кнопка «назад» Android
window.onAndroidBack = () => {
  if (!$("modal").classList.contains("hidden")) { closeModal(); return true; }
  if (!$("findBar").classList.contains("hidden")) { $("findClose").onclick(); return true; }
  if (S.view !== "code" && !wide()) { showView("code"); return true; }
  if (S.dirty) {
    ask("Корректор NC", "Есть несохранённые изменения. Выйти без сохранения?", ["Отмена", "Сохранить", "Выйти"]).then(a => {
      if (a === 1) $("bSave").onclick(); else if (a === 2 && bridge && bridge.exit) bridge.exit();
    });
    return true;
  }
  return false;
};
window.addEventListener("beforeunload", e => { if (S.dirty) { e.preventDefault(); e.returnValue = ""; } });
document.addEventListener("keydown", e => {
  if (e.ctrlKey && e.key === "z" && document.activeElement.tagName !== "TEXTAREA" && document.activeElement.tagName !== "INPUT") { e.preventDefault(); $("cUndo").onclick(); }
  if (e.ctrlKey && e.key === "s") { e.preventDefault(); $("bSave").onclick(); }
  if (e.key === "Escape") { if (v3d) { v3d.ruler = []; $("ruler3").classList.add("hidden"); v3d.refresh(); } view2d.clearRuler(); }
});

// ------------------------------------------------------------------ пример и запуск
const SAMPLE = `%
(TEST PROGRAM)
G90 G54 G17 G21
T1 M06
S18000 M03
G00 Z20
G00 X20 Y20
G01 Z-16.3 F3000
G01 X420 F12000
Y320
X20
Y20
G00 Z20
G00 X450 Y20
G01 Z-16.3 F3000
G01 X650 F12000
Y170
X450
Y20
G00 Z20
G00 X20 Y350
G01 Z-16.3 F3000
G01 X620 F12000
Y850
X20
Y350
G00 Z20
G00 X700 Y300
G01 Z-16.3 F3000
G02 X800 Y400 I100 J0 F9000
G03 X700 Y500 R100
G00 Z20
M05
T2 M06
M03 S18000
G00 Z20
G81 X100 Y600 Z-12 R5 F2000
G81 X164 Y600 Z-12 R5 F2000
G81 X228 Y600 Z-12 R5 F2000
G81 X292 Y600 Z-12 R5 F2000
G81 X356 Y600 Z-12 R5 F2000
G81 X420 Y600 Z-12 R5 F2000
G81 X484 Y600 Z-12 R5 F2000
G81 X548 Y600 Z-12 R5 F2000
G80
G00 Z20
M05
T3 M06
M03 S16000
G00 X900 Y50
G01 Z-16 F2000
G01 X1100 F8000
G00 Z20
M05
G53 X0 Y2800
M00
M30
%`;

(async function start() {
  await init3d();
  S.name = ""; setText("", { undoable: false });
  showView(wide() ? "2d" : "code");
  if (bridge && bridge.ready) bridge.ready();
  else toast("Откройте программу кнопкой 📂\nили ⋮ → «Открыть пример»", 3500);
})();

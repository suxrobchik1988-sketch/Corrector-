// 3D-модель листа: карта высот, съём материала, вид с вращением/масштабом/видами,
// указатель инструмента, выбор точки касанием и линейка.
import * as THREE from "./three.module.min.js";
import { toolColor } from "./nc.js";

const LAM = [236, 231, 220];
const THROUGH = [58, 60, 66];
// цвета вершин three.js считает линейными — переводим из sRGB, чтобы цвета были как задуманы
const LIN = new Uint8Array(256).map((_, i) => Math.round(255 * Math.pow(i / 255, 2.2)));
const hexRgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));

// ------------------------------------------------------------------ модель материала
export class StockSim {
  constructor(x0, y0, x1, y1, top, bottom, cell, maxCells = 1.4e6) {
    cell = Math.max(0.25, cell);
    const w = Math.max(x1 - x0, 1), hh = Math.max(y1 - y0, 1);
    while ((w / cell + 1) * (hh / cell + 1) > maxCells) cell *= 1.25;
    this.cell = cell; this.x0 = x0; this.y0 = y0;
    this.nx = Math.ceil(w / cell) + 1; this.ny = Math.ceil(hh / cell) + 1;
    this.x1 = x0 + (this.nx - 1) * cell; this.y1 = y0 + (this.ny - 1) * cell;
    this.top = top; this.bottom = bottom;
    this.xs = new Float32Array(this.nx); for (let i = 0; i < this.nx; i++) this.xs[i] = x0 + i * cell;
    this.ys = new Float32Array(this.ny); for (let i = 0; i < this.ny; i++) this.ys[i] = y0 + i * cell;
    const N = this.nx * this.ny;
    this.h = new Float32Array(N).fill(top);
    this.tid = new Int16Array(N);
    this.sdf = new Float32Array(N).fill(1e6);
    this.dirty = [0, this.ny - 1];
  }
  reset() { this.h.fill(this.top); this.tid.fill(0); this.sdf.fill(1e6); this.dirty = [0, this.ny - 1]; }
  _mark(r0, r1) { this.dirty = this.dirty ? [Math.min(this.dirty[0], r0), Math.max(this.dirty[1], r1)] : [r0, r1]; }
  cutPolyline(pts, r, tool) { for (let k = 0; k + 1 < pts.length; k++) this.cutSegment(pts[k], pts[k + 1], r, tool); }
  cutSegment(a, b, r, tool) {
    if (Math.min(a[2], b[2]) >= this.top - 1e-6) return;
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
    const n = Math.max(1, Math.ceil(L / 40));
    for (let k = 0; k < n; k++) {
      const t0 = k / n, t1 = (k + 1) / n;
      const pa = [0, 1, 2].map(i => a[i] + (b[i] - a[i]) * t0), pb = [0, 1, 2].map(i => a[i] + (b[i] - a[i]) * t1);
      this._cut(pa, pb, r, tool);
    }
  }
  _cut(a, b, r, tool) {
    if (Math.min(a[2], b[2]) >= this.top - 1e-6) return;
    const c = this.cell, m = r + 2 * c, nx = this.nx;
    const ix0 = Math.max(0, Math.floor((Math.min(a[0], b[0]) - m - this.x0) / c));
    const ix1 = Math.min(nx - 1, Math.ceil((Math.max(a[0], b[0]) + m - this.x0) / c));
    const iy0 = Math.max(0, Math.floor((Math.min(a[1], b[1]) - m - this.y0) / c));
    const iy1 = Math.min(this.ny - 1, Math.ceil((Math.max(a[1], b[1]) + m - this.y0) / c));
    if (ix0 > ix1 || iy0 > iy1) return;
    const dx = b[0] - a[0], dy = b[1] - a[1], L2 = dx * dx + dy * dy, dz = b[2] - a[2];
    const r2 = r * r, top = this.top, h = this.h, tid = this.tid, sdf = this.sdf;
    for (let iy = iy0; iy <= iy1; iy++) {
      const Y = this.ys[iy];
      for (let ix = ix0; ix <= ix1; ix++) {
        const X = this.xs[ix];
        let d2, z;
        if (L2 < 1e-12) { d2 = (X - a[0]) ** 2 + (Y - a[1]) ** 2; z = Math.min(a[2], b[2]); }
        else {
          const tc = ((X - a[0]) * dx + (Y - a[1]) * dy) / L2;
          const perp2 = (X - (a[0] + tc * dx)) ** 2 + (Y - (a[1] + tc * dy)) ** 2;
          const t = Math.min(1, Math.max(0, tc));
          d2 = (X - (a[0] + t * dx)) ** 2 + (Y - (a[1] + t * dy)) ** 2;
          const w = Math.sqrt(Math.max(r2 - perp2, 0) / L2);
          const tz = dz < 0 ? Math.min(1, Math.max(0, tc + w)) : Math.min(1, Math.max(0, tc - w));
          z = a[2] + tz * dz;
        }
        const k = iy * nx + ix;
        const dist = Math.sqrt(d2) - r;
        if (z < top - 1e-4 && dist < 2 * c && dist < sdf[k]) sdf[k] = dist;
        if (d2 <= r2 && z < h[k]) { h[k] = z; tid[k] = tool; }
      }
    }
    this._mark(iy0, iy1);
  }
}

// ------------------------------------------------------------------ вид
export const VIEWS = {
  iso: [-60, 35], top: [-90, 90], bottom: [90, -90], front: [-90, 0], back: [90, 0], left: [180, 0], right: [0, 0],
};

export class Viewer3D {
  constructor(container, opts = {}) {
    this.el = container;
    this.toolRadius = opts.toolRadius || (() => 3);
    this.onTap = opts.onTap || (() => {});
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setClearColor(0xeef0f4);
    container.appendChild(this.renderer.domElement);
    this.canvas = this.renderer.domElement;
    this.canvas.style.touchAction = "none";
    this.scene = new THREE.Scene();
    this.persp = new THREE.PerspectiveCamera(35, 1, 1, 1e6);
    this.orthoCam = new THREE.OrthographicCamera(-1, 1, 1, -1, -1e6, 1e6);
    this.ortho = false;
    this.light = new THREE.DirectionalLight(0xffffff, 1.6);
    this.amb = new THREE.AmbientLight(0xffffff, 1.5);
    this.scene.add(this.amb);
    this.scene.add(this.light);
    this.scene.add(this.light.target);
    this.yaw = VIEWS.iso[0]; this.pitch = VIEWS.iso[1]; this.dist = 3000; this.target = [0, 0, 0];
    this.showPaths = true; this.showStock = true;
    this.sim = null; this.stock = null; this.pathsObj = null; this.marker = null;
    this.hover = null; this.ruler = []; this.rulerMode = false;
    this.vtx = null;
    this.marks = new THREE.Group(); this.marks.renderOrder = 10; this.scene.add(this.marks);
    this.axes = new THREE.Group(); this.scene.add(this.axes);
    this._needs = true; this._raf = null;
    this._ptrs = new Map(); this._tap = null;
    this._bindInput();
    new ResizeObserver(() => this.resize()).observe(container);
    this.resize();
  }

  // ---------------- камера
  camera() { return this.ortho ? this.orthoCam : this.persp; }
  _eye() {
    const y = this.yaw * Math.PI / 180, p = this.pitch * Math.PI / 180;
    const e = [this.target[0] + this.dist * Math.cos(p) * Math.cos(y),
      this.target[1] + this.dist * Math.cos(p) * Math.sin(y), this.target[2] + this.dist * Math.sin(p)];
    const up = [-Math.sin(p) * Math.cos(y), -Math.sin(p) * Math.sin(y), Math.cos(p)];
    return [e, up];
  }
  _updateCamera() {
    const w = Math.max(this.el.clientWidth, 1), h = Math.max(this.el.clientHeight, 1), asp = w / h;
    const [e, up] = this._eye();
    for (const cam of [this.persp, this.orthoCam]) {
      cam.position.set(...e); cam.up.set(...up); cam.lookAt(...this.target);
    }
    this.persp.aspect = asp; this.persp.near = Math.max(this.dist * 0.01, 0.5); this.persp.far = this.dist * 20;
    this.persp.updateProjectionMatrix();
    const half = this.dist * Math.tan(17.5 * Math.PI / 180);
    Object.assign(this.orthoCam, { left: -half * asp, right: half * asp, top: half, bottom: -half, near: -this.dist * 20, far: this.dist * 20 });
    this.orthoCam.updateProjectionMatrix();
    // «фонарь» от камеры
    const cam = this.camera();
    this.light.position.set(...e).add(new THREE.Vector3(0.3, 0.45, 0).applyQuaternion(cam.quaternion).multiplyScalar(this.dist));
    this.light.target.position.set(...this.target);
  }
  resize() {
    const w = Math.max(this.el.clientWidth, 1), h = Math.max(this.el.clientHeight, 1);
    this.renderer.setSize(w, h, false);
    this.canvas.style.width = w + "px"; this.canvas.style.height = h + "px";
    this.refresh();
  }
  setView(name) { [this.yaw, this.pitch] = VIEWS[name]; this.refresh(); }
  fit() {
    if (this.sim) {
      const s = this.sim;
      this.target = [(s.x0 + s.x1) / 2, (s.y0 + s.y1) / 2, (s.top + s.bottom) / 2];
      const asp = Math.max(this.el.clientWidth, 1) / Math.max(this.el.clientHeight, 1);
      this.dist = Math.max(s.x1 - s.x0, s.y1 - s.y0) * 1.45 / Math.min(1, asp);
    }
    this.refresh();
  }
  zoom(f) { this.dist = Math.max(5, this.dist * f); this.refresh(); }
  refresh() {
    this._needs = true;
    if (!this._raf) this._raf = requestAnimationFrame(() => { this._raf = null; this.render(); });
  }

  // ---------------- ввод: 1 палец — вращение, 2 — сдвиг и масштаб, касание — точка
  _bindInput() {
    const c = this.canvas;
    c.addEventListener("pointerdown", e => {
      c.setPointerCapture(e.pointerId);
      this._ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, btn: e.button });
      this._tap = this._ptrs.size === 1 ? { x: e.clientX, y: e.clientY, t: performance.now(), moved: false } : null;
    });
    c.addEventListener("pointermove", e => {
      const p = this._ptrs.get(e.pointerId);
      if (!p) { if (e.pointerType === "mouse") this._hoverAt(e); return; }
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      if (this._tap && Math.hypot(e.clientX - this._tap.x, e.clientY - this._tap.y) > 6) this._tap.moved = true;
      if (this._ptrs.size === 1) {
        if (p.btn === 2 || p.btn === 1) this._pan(dx, dy);
        else { this.yaw -= dx * 0.4; this.pitch = Math.max(-90, Math.min(90, this.pitch + dy * 0.4)); }
      } else if (this._ptrs.size === 2) {
        const [a, b] = [...this._ptrs.values()];
        const d0 = Math.hypot(a.x - b.x, a.y - b.y);
        const cx0 = (a.x + b.x) / 2, cy0 = (a.y + b.y) / 2;
        p.x = e.clientX; p.y = e.clientY;
        const [a2, b2] = [...this._ptrs.values()];
        const d1 = Math.hypot(a2.x - b2.x, a2.y - b2.y);
        this._pan((a2.x + b2.x) / 2 - cx0, (a2.y + b2.y) / 2 - cy0);
        if (d1 > 1 && d0 > 1) this.dist = Math.max(5, this.dist * d0 / d1);
        this.refresh(); return;
      }
      p.x = e.clientX; p.y = e.clientY;
      this.refresh();
    });
    const up = e => {
      this._ptrs.delete(e.pointerId);
      const t = this._tap;
      if (t && !t.moved && performance.now() - t.t < 500 && this._ptrs.size === 0) {
        const r = c.getBoundingClientRect();
        this.onTap(this.pick(e.clientX - r.left, e.clientY - r.top, e.pointerType === "mouse" ? 10 : 22),
          e.clientX - r.left, e.clientY - r.top);
      }
      if (this._ptrs.size === 0) this._tap = null;
    };
    c.addEventListener("pointerup", up);
    c.addEventListener("pointercancel", e => { this._ptrs.delete(e.pointerId); this._tap = null; });
    c.addEventListener("contextmenu", e => e.preventDefault());
    c.addEventListener("wheel", e => { e.preventDefault(); this.zoom(e.deltaY < 0 ? 0.85 : 1 / 0.85); }, { passive: false });
  }
  _hoverAt(e) {
    if (!this.onHover) return;
    const r = this.canvas.getBoundingClientRect();
    this.onHover(this.pick(e.clientX - r.left, e.clientY - r.top, 10), e.clientX - r.left, e.clientY - r.top);
  }
  _pan(dx, dy) {
    const cam = this.camera();
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(cam.quaternion);
    const upv = new THREE.Vector3(0, 1, 0).applyQuaternion(cam.quaternion);
    const k = this.dist * 0.0016 * (900 / Math.max(this.el.clientHeight, 300));
    for (let i = 0; i < 3; i++) this.target[i] += (-dx * right.getComponent(i) + dy * upv.getComponent(i)) * k;
  }

  // ---------------- выбор точки траектории
  setPaths(segs) {
    if (this.pathsObj) { this.scene.remove(this.pathsObj); this.pathsObj.geometry.dispose(); }
    let n = 0;
    for (const s of segs) n += Math.max(0, s.pts.length - 1) * 2;
    const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
    let k = 0;
    const vv = [], vl = [], vt = [];
    for (const s of segs) {
      const rgb = s.kind === "rapid" ? [150, 150, 150] : hexRgb(toolColor(s.tool));
      for (let i = 0; i + 1 < s.pts.length; i++) {
        for (const p of [s.pts[i], s.pts[i + 1]]) {
          pos[k * 3] = p[0]; pos[k * 3 + 1] = p[1]; pos[k * 3 + 2] = p[2];
          col[k * 3] = rgb[0] / 255; col[k * 3 + 1] = rgb[1] / 255; col[k * 3 + 2] = rgb[2] / 255; k++;
        }
      }
      for (const p of s.pts) { vv.push(p[0], p[1], p[2]); vl.push(s.line); vt.push(s.tool === null ? -1 : s.tool); }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(col, 3));
    this.pathsObj = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ vertexColors: true }));
    this.pathsObj.visible = this.showPaths;
    this.scene.add(this.pathsObj);
    this.vtx = { p: new Float64Array(vv), line: Int32Array.from(vl), tool: Int32Array.from(vt) };
    this.hover = null; this.ruler = [];
    this.refresh();
  }
  pick(sx, sy, tol = 12) {
    if (!this.vtx || !this.vtx.line.length) return null;
    this._updateCamera();
    const cam = this.camera();
    cam.updateMatrixWorld();
    const m = new THREE.Matrix4().multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse).elements;
    const w = this.el.clientWidth, h = this.el.clientHeight, P = this.vtx.p;
    let best = -1, bd = Infinity, bz = Infinity;
    for (let i = 0, n = this.vtx.line.length; i < n; i++) {
      const x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2];
      const cw = m[3] * x + m[7] * y + m[11] * z + m[15];
      if (cw <= 1e-9 && !this.ortho) continue;
      const W = this.ortho ? 1 : cw;
      const nx = (m[0] * x + m[4] * y + m[8] * z + m[12]) / W, ny = (m[1] * x + m[5] * y + m[9] * z + m[13]) / W;
      const nz = (m[2] * x + m[6] * y + m[10] * z + m[14]) / W;
      if (Math.abs(nz) > 1) continue;
      const px = (nx + 1) / 2 * w, py = (1 - ny) / 2 * h;
      const d2 = Math.round((px - sx) ** 2 + (py - sy) ** 2);
      if (d2 > tol * tol) continue;
      if (d2 < bd || (d2 === bd && nz < bz)) { best = i; bd = d2; bz = nz; }
    }
    if (best < 0) return null;
    const t = this.vtx.tool[best];
    return { x: P[best * 3], y: P[best * 3 + 1], z: P[best * 3 + 2], line: this.vtx.line[best], tool: t < 0 ? null : t };
  }

  // ---------------- лист
  setSim(sim) {
    if (this.stock) { for (const o of this.stock.objs) { this.scene.remove(o); o.geometry.dispose(); } }
    this.sim = sim; this.stock = null;
    if (sim) this._buildStock();
    this.fit();
  }
  _buildStock() {
    const s = this.sim, nx = s.nx, ny = s.ny, N = nx * ny;
    const idx = new Uint32Array((nx - 1) * (ny - 1) * 6);
    let k = 0;
    for (let iy = 0; iy < ny - 1; iy++) for (let ix = 0; ix < nx - 1; ix++) {
      const a = iy * nx + ix, b = a + 1, c = a + nx, d = c + 1;
      idx[k++] = a; idx[k++] = b; idx[k++] = d; idx[k++] = a; idx[k++] = d; idx[k++] = c;
    }
    const mk = () => {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(N * 3), 3));
      g.setAttribute("normal", new THREE.BufferAttribute(new Float32Array(N * 3), 3));
      g.setAttribute("color", new THREE.BufferAttribute(new Uint8Array(N * 3), 3, true));
      g.setIndex(new THREE.BufferAttribute(idx, 1));
      for (const a of ["position", "normal", "color"]) g.getAttribute(a).setUsage(THREE.DynamicDrawUsage);
      return g;
    };
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    const top = new THREE.Mesh(mk(), mat), bot = new THREE.Mesh(mk(), mat);
    top.frustumCulled = bot.frustumCulled = false;
    const walls = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshLambertMaterial({ color: 0xa8916a, side: THREE.DoubleSide }));
    walls.frustumCulled = false;
    const table = new THREE.Mesh(new THREE.PlaneGeometry(s.x1 - s.x0 + 120, s.y1 - s.y0 + 120),
      new THREE.MeshBasicMaterial({ color: 0x8c9199 }));
    table.position.set((s.x0 + s.x1) / 2, (s.y0 + s.y1) / 2, s.bottom - 0.6);
    this.stock = { top, bot, walls, table, objs: [top, bot, walls, table], full: true };
    for (const o of this.stock.objs) this.scene.add(o);
    this._applyVisibility();
  }
  _rows(r0, r1) {
    const s = this.sim, c = s.cell, nx = s.nx, ny = s.ny, st = this.stock;
    const P = st.top.geometry.attributes.position.array, Nn = st.top.geometry.attributes.normal.array, C = st.top.geometry.attributes.color.array;
    const BP = st.bot.geometry.attributes.position.array, BN = st.bot.geometry.attributes.normal.array, BC = st.bot.geometry.attributes.color.array;
    const thick = Math.max(s.top - s.bottom, 1e-3);
    const sd = (iy, ix) => Math.max(-3 * c, Math.min(3 * c, s.sdf[iy * nx + ix]));
    for (let iy = r0; iy <= r1; iy++) {
      for (let ix = 0; ix < nx; ix++) {
        const k = iy * nx + ix;
        const through = s.h[k] <= s.bottom + 0.02;
        const hr = through ? s.bottom + 0.05 : Math.max(s.h[k], s.bottom);
        const sv = sd(iy, ix);
        const gx = nx < 2 ? 0 : (ix === 0 ? (sd(iy, 1) - sv) / c : ix === nx - 1 ? (sv - sd(iy, ix - 1)) / c : (sd(iy, ix + 1) - sd(iy, ix - 1)) / (2 * c));
        const gy = ny < 2 ? 0 : (iy === 0 ? (sd(1, ix) - sv) / c : iy === ny - 1 ? (sv - sd(iy - 1, ix)) / c : (sd(iy + 1, ix) - sd(iy - 1, ix)) / (2 * c));
        const gn = Math.hypot(gx, gy);
        let X = s.xs[ix], Y = s.ys[iy];
        if (sv > -0.6 * c && sv < c && gn > 0.5) { const f = -sv / Math.max(gn, 1e-6); X += f * gx; Y += f * gy; }
        X = Math.min(s.x1, Math.max(s.x0, X)); Y = Math.min(s.y1, Math.max(s.y0, Y));
        const k3 = k * 3;
        P[k3] = X; P[k3 + 1] = Y; P[k3 + 2] = hr;
        BP[k3] = X; BP[k3 + 1] = Y; BP[k3 + 2] = s.bottom;
        let n0 = 0, n1 = 0, n2 = 1;
        if (sv < 0.05 && sv > -c && gn > 0.5 && hr < s.top - 0.05) { n0 = -gx / gn; n1 = -gy / gn; n2 = 0.25; }
        else if (sv >= 0.05 && sv < 1.2 * c && gn > 0.5) { n0 = gx / gn * 0.35; n1 = gy / gn * 0.35; }
        const nl = Math.hypot(n0, n1, n2);
        Nn[k3] = n0 / nl; Nn[k3 + 1] = n1 / nl; Nn[k3 + 2] = n2 / nl;
        BN[k3] = 0; BN[k3 + 1] = 0; BN[k3 + 2] = 1;
        let col = LAM;
        const t = s.tid[k];
        if (through) col = THROUGH;
        else if (t !== 0) {
          const base = hexRgb(toolColor(t)), depth = Math.min(1, Math.max(0, (s.top - hr) / thick)), sh = 0.8 - 0.4 * depth;
          col = [0, 1, 2].map(i => (base[i] * 0.75 + LAM[i] * 0.25) * sh);
        }
        C[k3] = LIN[col[0] | 0]; C[k3 + 1] = LIN[col[1] | 0]; C[k3 + 2] = LIN[col[2] | 0];
        const bc = through ? THROUGH : [LAM[0] * 0.92, LAM[1] * 0.92, LAM[2] * 0.92];
        BC[k3] = LIN[bc[0] | 0]; BC[k3 + 1] = LIN[bc[1] | 0]; BC[k3 + 2] = LIN[bc[2] | 0];
      }
    }
    const off = r0 * nx * 3, cnt = (r1 - r0 + 1) * nx * 3;
    for (const g of [st.top.geometry, st.bot.geometry]) for (const a of ["position", "normal", "color"]) {
      const at = g.attributes[a];
      if (at.addUpdateRange) { at.clearUpdateRanges(); at.addUpdateRange(off, cnt); }
      at.needsUpdate = true;
    }
  }
  _walls() {
    const s = this.sim, nx = s.nx, ny = s.ny, v = [];
    const H = (iy, ix) => Math.max(s.h[iy * nx + ix], s.bottom);
    const edge = (n, fx, fy, fh) => {
      for (let i = 0; i + 1 < n; i++) {
        const xa = fx(i), ya = fy(i), xb = fx(i + 1), yb = fy(i + 1), ha = fh(i), hb = fh(i + 1);
        v.push(xa, ya, s.bottom, xb, yb, s.bottom, xb, yb, hb, xa, ya, s.bottom, xb, yb, hb, xa, ya, ha);
      }
    };
    edge(nx, i => s.xs[i], () => s.y0, i => H(0, i));
    edge(nx, i => s.xs[i], () => s.y1, i => H(ny - 1, i));
    edge(ny, () => s.x0, i => s.ys[i], i => H(i, 0));
    edge(ny, () => s.x1, i => s.ys[i], i => H(i, nx - 1));
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(v), 3));
    g.computeVertexNormals();
    this.stock.walls.geometry.dispose();
    this.stock.walls.geometry = g;
  }
  _upload() {
    const s = this.sim;
    if (!s || !this.stock) return;
    if (this.stock.full) { this._rows(0, s.ny - 1); this.stock.full = false; s.dirty = null; this._walls(); }
    else if (s.dirty) {
      const r0 = Math.max(0, s.dirty[0] - 2), r1 = Math.min(s.ny - 1, s.dirty[1] + 2);
      this._rows(r0, r1);
      this._walls();
      s.dirty = null;
    }
  }
  resetStock() { if (this.sim) { this.sim.reset(); if (this.stock) this.stock.full = true; this.refresh(); } }
  _applyVisibility() {
    if (this.stock) for (const o of this.stock.objs) o.visible = this.showStock;
    if (this.stock) this.stock.table.visible = this.showStock && this.pitch > 0;
    if (this.pathsObj) this.pathsObj.visible = this.showPaths;
  }

  // ---------------- указатель инструмента, точка, линейка, оси
  setToolMarker(m) { this.toolMarker = m; this.refresh(); }
  _buildMarker() {
    if (this.marker) { this.scene.remove(this.marker); this.marker.traverse(o => o.geometry && o.geometry.dispose()); this.marker = null; }
    const m = this.toolMarker;
    if (!m) return;
    const g = new THREE.Group();
    const col = new THREE.Color(toolColor(m.tool));
    const cyl = (r, h, color, z0) => {
      const geo = new THREE.CylinderGeometry(r, r, h, 28);
      geo.rotateX(Math.PI / 2);
      const mesh = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ color }));
      mesh.position.set(0, 0, z0 + h / 2);
      g.add(mesh);
    };
    cyl(m.r, 30, col, 0);
    cyl(Math.max(m.r * 1.6, 6), 40, 0xbfbfc7, 30);
    const top = 70, hgt = Math.max(this.dist * 0.1, 40);
    const lg = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, top), new THREE.Vector3(0, 0, top + hgt)]);
    const line = new THREE.Line(lg, new THREE.LineBasicMaterial({ color: col, depthTest: false }));
    line.renderOrder = 20; g.add(line);
    const dot = new THREE.Mesh(new THREE.SphereGeometry(Math.max(this.dist * 0.008, 4), 12, 8),
      new THREE.MeshBasicMaterial({ color: col, depthTest: false }));
    dot.position.set(0, 0, top + hgt); dot.renderOrder = 20; g.add(dot);
    g.position.set(m.x, m.y, m.z);
    this.marker = g; this.scene.add(g);
  }
  _buildMarks() {
    this.marks.traverse(o => o.geometry && o.geometry.dispose());
    this.marks.clear();
    const rs = Math.max(this.dist * 0.006, 2.5);
    const dot = (p, color, r) => {
      const m = new THREE.Mesh(new THREE.SphereGeometry(r, 12, 8), new THREE.MeshBasicMaterial({ color, depthTest: false }));
      m.position.set(p[0], p[1], p[2]); m.renderOrder = 30; this.marks.add(m);
    };
    const pts = this.ruler.slice();
    if (pts.length === 1 && this.hover) pts.push([this.hover.x, this.hover.y, this.hover.z]);
    if (pts.length === 2) {
      const lg = new THREE.BufferGeometry().setFromPoints(pts.map(p => new THREE.Vector3(...p)));
      const l = new THREE.Line(lg, new THREE.LineBasicMaterial({ color: 0xe00070, depthTest: false }));
      l.renderOrder = 30; this.marks.add(l);
    }
    for (const p of pts) dot(p, 0xe00070, rs);
    if (this.hover) { dot([this.hover.x, this.hover.y, this.hover.z], 0xc00000, rs * 1.5); dot([this.hover.x, this.hover.y, this.hover.z], 0xffd400, rs); }
  }
  _buildAxes() {
    this.axes.traverse(o => o.geometry && o.geometry.dispose());
    this.axes.clear();
    const L = Math.max(this.dist * 0.06, 20), z = (this.sim ? this.sim.top : 0) + 0.5;
    for (const [d, c] of [[[L, 0, 0], 0xd91a1a], [[0, L, 0], 0x1aa61a], [[0, 0, L], 0x1a40e6]]) {
      const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, z), new THREE.Vector3(d[0], d[1], z + d[2])]);
      this.axes.add(new THREE.Line(g, new THREE.LineBasicMaterial({ color: c })));
    }
  }
  render() {
    if (!this.el.clientWidth) return;
    this._updateCamera();
    this._applyVisibility();
    if (this.showStock) this._upload();
    this._buildMarker();
    this._buildMarks();
    this._buildAxes();
    this.renderer.render(this.scene, this.camera());
  }
}

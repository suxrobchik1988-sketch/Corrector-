// План 2D: траектории по цветам инструментов, касание — координаты точки,
// линейка-измеритель, шкалы в мм, сдвиг/масштаб пальцами.
import { toolColor, fnum, RAPID_COLOR } from "./nc.js";

export class View2D {
  constructor(container, opts) {
    this.el = container;
    this.o = opts;            // toolRadius(t), onTap(info), onRuler(text)
    this.canvas = document.createElement("canvas");
    this.canvas.style.touchAction = "none";
    container.appendChild(this.canvas);
    this.ctx = this.canvas.getContext("2d");
    this.k = 1; this.tx = 40; this.ty = 300;
    this.res = null; this.filter = {}; this.showRapid = true;
    this.limit = null;        // при проигрывании — сколько сегментов показано
    this.sel = null;          // выбранная строка
    this.pos = null;          // {x,y,z,tool} — где инструмент
    this.tip = null;          // точка под пальцем / мышью
    this.rulerMode = false; this.ruler = [];
    this._ptrs = new Map(); this._tap = null; this._raf = null;
    this._bind();
    new ResizeObserver(() => this.resize()).observe(container);
    this.resize();
  }
  w2s(x, y) { return [x * this.k + this.tx, -y * this.k + this.ty]; }
  s2w(sx, sy) { return [(sx - this.tx) / this.k, -(sy - this.ty) / this.k]; }
  resize() {
    const dpr = window.devicePixelRatio || 1;
    const w = this.el.clientWidth, h = this.el.clientHeight;
    this.canvas.width = Math.max(1, w * dpr); this.canvas.height = Math.max(1, h * dpr);
    this.canvas.style.width = w + "px"; this.canvas.style.height = h + "px";
    this.dpr = dpr;
    if (!this._fitted && w > 50 && this.res) { this._fitted = true; this.fit(); }
    this.draw();
  }
  setResult(res) {
    this.res = res;
    const xs = [], ys = [], zs = [], ln = [], tl = [];
    for (const s of res.segs) for (const p of s.pts) { xs.push(p[0]); ys.push(p[1]); zs.push(p[2]); ln.push(s.line); tl.push(s.tool === null ? -1 : s.tool); }
    this.vtx = { x: Float64Array.from(xs), y: Float64Array.from(ys), z: Float64Array.from(zs), line: Int32Array.from(ln), tool: Int32Array.from(tl) };
    this.tip = null; this.ruler = [];
    this.draw();
  }
  fit() {
    const w = Math.max(this.el.clientWidth, 200), h = Math.max(this.el.clientHeight, 200);
    if (!this.res || !this.res.bounds) { this.k = 1; this.tx = 60; this.ty = h - 40; this.draw(); return; }
    let [x0, y0, x1, y1] = this.res.bounds;
    x0 = Math.min(x0, 0); y0 = Math.min(y0, 0);
    const bw = Math.max(x1 - x0, 1), bh = Math.max(y1 - y0, 1);
    this.k = Math.min((w - 70) / bw, (h - 50) / bh);
    this.tx = 55 - x0 * this.k + ((w - 70) - bw * this.k) / 2;
    this.ty = h - 18 + y0 * this.k - ((h - 50) - bh * this.k) / 2;
    this.draw();
  }
  visible(tool, kind) {
    if (this.filter[tool] === false) return false;
    return kind !== "rapid" || this.showRapid;
  }
  draw() {
    if (this._raf) return;
    this._raf = requestAnimationFrame(() => { this._raf = null; this._draw(); });
  }

  // ---------------- ввод
  _bind() {
    const c = this.canvas;
    c.addEventListener("pointerdown", e => {
      c.setPointerCapture(e.pointerId);
      this._ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
      this._tap = this._ptrs.size === 1 ? { x: e.clientX, y: e.clientY, t: performance.now(), moved: false } : null;
    });
    c.addEventListener("pointermove", e => {
      const p = this._ptrs.get(e.pointerId);
      const r = c.getBoundingClientRect();
      if (!p) {
        if (e.pointerType === "mouse") { this.tip = this.snap(e.clientX - r.left, e.clientY - r.top, 9); this.draw(); }
        return;
      }
      if (this._tap && Math.hypot(e.clientX - this._tap.x, e.clientY - this._tap.y) > 6) this._tap.moved = true;
      if (this._ptrs.size === 1) {
        if (this._tap && !this._tap.moved) return;
        this.tx += e.clientX - p.x; this.ty += e.clientY - p.y;
      } else if (this._ptrs.size === 2) {
        const [a, b] = [...this._ptrs.values()];
        const d0 = Math.hypot(a.x - b.x, a.y - b.y), cx0 = (a.x + b.x) / 2, cy0 = (a.y + b.y) / 2;
        p.x = e.clientX; p.y = e.clientY;
        const [a2, b2] = [...this._ptrs.values()];
        const d1 = Math.hypot(a2.x - b2.x, a2.y - b2.y), cx1 = (a2.x + b2.x) / 2, cy1 = (a2.y + b2.y) / 2;
        this.tx += cx1 - cx0; this.ty += cy1 - cy0;
        if (d0 > 1 && d1 > 1) this._zoom(cx1 - r.left, cy1 - r.top, d1 / d0);
        this.draw(); return;
      }
      p.x = e.clientX; p.y = e.clientY;
      this.draw();
    });
    const up = e => {
      this._ptrs.delete(e.pointerId);
      const t = this._tap;
      if (t && !t.moved && performance.now() - t.t < 500 && this._ptrs.size === 0) {
        const r = c.getBoundingClientRect();
        this._tapAt(e.clientX - r.left, e.clientY - r.top, e.pointerType === "mouse" ? 9 : 20);
      }
      if (this._ptrs.size === 0) this._tap = null;
    };
    c.addEventListener("pointerup", up);
    c.addEventListener("pointercancel", e => { this._ptrs.delete(e.pointerId); this._tap = null; });
    c.addEventListener("pointerleave", e => { if (e.pointerType === "mouse") { this.tip = null; this.draw(); } });
    c.addEventListener("wheel", e => {
      e.preventDefault();
      const r = c.getBoundingClientRect();
      this._zoom(e.clientX - r.left, e.clientY - r.top, e.deltaY < 0 ? 1.2 : 1 / 1.2); this.draw();
    }, { passive: false });
    c.addEventListener("dblclick", () => this.fit());
  }
  _zoom(cx, cy, f) {
    this.k *= f; this.tx = cx + (this.tx - cx) * f; this.ty = cy + (this.ty - cy) * f;
  }
  _tapAt(sx, sy, tol) {
    const info = this.snap(sx, sy, tol);
    if (this.rulerMode) {
      const p = info ? [info.x, info.y, info.z] : [...this.s2w(sx, sy), 0];
      if (this.ruler.length >= 2) this.ruler = [];
      this.ruler.push(p);
      this.tip = info;
      if (this.ruler.length === 2 && this.o.onRuler) this.o.onRuler(this.rulerText(this.ruler[0], this.ruler[1]));
      this.draw(); return;
    }
    this.tip = info;
    this.draw();
    if (info && this.o.onTap) this.o.onTap(info);
  }
  clearRuler() { this.ruler = []; this.draw(); }
  rulerText(a, b) {
    const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
    return { L: Math.hypot(dx, dy), dx, dy, dz, ang: Math.atan2(dy, dx) * 180 / Math.PI };
  }

  // ближайшая вершина (или точка на линии) под пальцем
  snap(sx, sy, px) {
    if (!this.vtx || !this.vtx.x.length) return null;
    const [wx, wy] = this.s2w(sx, sy), tol = px / Math.max(this.k, 1e-9), V = this.vtx;
    const lim = this._vertexLimit();
    let bi = -1, bd = Infinity;
    for (let i = 0; i < lim; i++) {
      const t = V.tool[i] < 0 ? null : V.tool[i];
      if (this.filter[t] === false) continue;
      const d = (V.x[i] - wx) ** 2 + (V.y[i] - wy) ** 2;
      if (d < bd) { bd = d; bi = i; }
    }
    if (bi >= 0 && bd <= tol * tol) {
      const t = V.tool[bi];
      return { x: V.x[bi], y: V.y[bi], z: V.z[bi], line: V.line[bi], tool: t < 0 ? null : t, vertex: true };
    }
    let best = null, bdist = tol * tol;
    const segs = this.res.segs, n = this.limit ?? segs.length;
    for (let si = 0; si < n; si++) {
      const s = segs[si];
      if (!this.visible(s.tool, s.kind) || s.kind === "drill") continue;
      for (let k = 0; k + 1 < s.pts.length; k++) {
        const a = s.pts[k], b = s.pts[k + 1], dx = b[0] - a[0], dy = b[1] - a[1], L2 = dx * dx + dy * dy;
        const t = L2 < 1e-12 ? 0 : Math.max(0, Math.min(1, ((wx - a[0]) * dx + (wy - a[1]) * dy) / L2));
        const qx = a[0] + t * dx, qy = a[1] + t * dy, d = (qx - wx) ** 2 + (qy - wy) ** 2;
        if (d < bdist) { bdist = d; best = { x: qx, y: qy, z: a[2] + t * (b[2] - a[2]), line: s.line, tool: s.tool, vertex: false }; }
      }
    }
    return best;
  }
  _vertexLimit() {
    if (this.limit === null || !this.res) return this.vtx.x.length;
    let n = 0;
    for (let i = 0; i < this.limit && i < this.res.segs.length; i++) n += this.res.segs[i].pts.length;
    return n;
  }

  // ---------------- рисование
  _draw() {
    const c = this.ctx, dpr = this.dpr || 1, w = this.el.clientWidth, h = this.el.clientHeight;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.fillStyle = "#ffffff"; c.fillRect(0, 0, w, h);
    const R = this.res;
    if (R && R.bounds) {
      const [x0, y0, x1, y1] = R.bounds;
      const [ax, ay] = this.w2s(0, 0);
      const [sx0, sy0] = this.w2s(x0, y0), [sx1, sy1] = this.w2s(x1, y1);
      c.setLineDash([2, 4]); c.strokeStyle = "#dcdcdc"; c.lineWidth = 1;
      c.strokeRect(sx0, sy1, sx1 - sx0, sy0 - sy1); c.setLineDash([]);
      c.lineWidth = 2;
      c.strokeStyle = "#cc0000"; c.beginPath(); c.moveTo(ax - 12, ay); c.lineTo(ax + 36, ay); c.stroke();
      c.strokeStyle = "#00aa00"; c.beginPath(); c.moveTo(ax, ay + 12); c.lineTo(ax, ay - 36); c.stroke();
      // траектории — пачками по цвету
      const n = this.limit ?? R.segs.length;
      const groups = new Map();
      for (let i = 0; i < n; i++) {
        const s = R.segs[i];
        if (!this.visible(s.tool, s.kind)) continue;
        const key = s.kind === "rapid" ? "rapid" : s.kind + "|" + s.tool;
        let g = groups.get(key); if (!g) { g = new Path2D(); groups.set(key, g); }
        if (s.kind === "drill") {
          const [x, y] = this.w2s(s.pts[0][0], s.pts[0][1]);
          const r = Math.max(2, this.o.toolRadius(s.tool) * this.k);
          g.moveTo(x + r, y); g.arc(x, y, r, 0, Math.PI * 2);
        } else {
          let [px, py] = this.w2s(s.pts[0][0], s.pts[0][1]); g.moveTo(px, py);
          for (let k = 1; k < s.pts.length; k++) { [px, py] = this.w2s(s.pts[k][0], s.pts[k][1]); g.lineTo(px, py); }
        }
      }
      for (const [key, g] of groups) {
        if (key === "rapid") { c.setLineDash([3, 3]); c.strokeStyle = RAPID_COLOR; c.lineWidth = 1; }
        else { c.setLineDash([]); const t = key.split("|")[1]; c.strokeStyle = toolColor(t === "null" ? null : Number(t)); c.lineWidth = 1.5; }
        c.stroke(g);
      }
      c.setLineDash([]);
      // выбранная строка
      if (this.sel !== null) {
        for (const s of R.segs) {
          if (s.line !== this.sel) continue;
          if (s.kind === "drill") {
            const [x, y] = this.w2s(s.pts[0][0], s.pts[0][1]);
            c.strokeStyle = "#000"; c.lineWidth = 3; c.beginPath(); c.arc(x, y, 8, 0, Math.PI * 2); c.stroke();
          } else {
            const path = new Path2D();
            s.pts.forEach((p, k) => { const [x, y] = this.w2s(p[0], p[1]); k ? path.lineTo(x, y) : path.moveTo(x, y); });
            c.strokeStyle = "#ffcc00"; c.lineWidth = 6; c.stroke(path);
            c.strokeStyle = toolColor(s.tool); c.lineWidth = 2.5; c.stroke(path);
          }
        }
      }
      // инструмент
      if (this.pos) {
        const [x, y] = this.w2s(this.pos.x, this.pos.y), col = toolColor(this.pos.tool);
        const r = Math.max(5, this.o.toolRadius(this.pos.tool) * this.k);
        c.fillStyle = col; c.strokeStyle = "#000"; c.lineWidth = 1.5;
        c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill(); c.stroke();
        c.font = "bold 12px monospace"; c.fillStyle = col;
        c.fillText(`${this.pos.tool !== null ? "T" + this.pos.tool : "—"}  Z${fnum(Math.round(this.pos.z * 100) / 100)}`, x + r + 4, y - r - 4);
      }
    }
    this._overlays(c, w, h);
  }
  _label(c, x, y, lines, bg, border, w, h) {
    c.font = "12px monospace";
    const lw = Math.max(...lines.map(s => c.measureText(s).width)) + 10, lh = lines.length * 15 + 6;
    let bx = x + 14, by = y - 14 - lh;
    if (bx + lw > w - 2) bx = x - 14 - lw;
    if (by < 24) by = y + 14;
    c.fillStyle = bg; c.fillRect(bx, by, lw, lh);
    if (border) { c.strokeStyle = border; c.lineWidth = 1.5; c.strokeRect(bx, by, lw, lh); }
    c.fillStyle = "#fff";
    lines.forEach((s, i) => c.fillText(s, bx + 5, by + 15 + i * 15));
  }
  _overlays(c, w, h) {
    // линейка
    const pts = this.ruler.slice();
    if (pts.length === 1 && this.tip) pts.push([this.tip.x, this.tip.y, this.tip.z]);
    if (pts.length) {
      const sp = pts.map(p => this.w2s(p[0], p[1]));
      if (sp.length === 2) {
        c.strokeStyle = "#e00070"; c.lineWidth = 2; c.setLineDash([6, 3]);
        c.beginPath(); c.moveTo(...sp[0]); c.lineTo(...sp[1]); c.stroke(); c.setLineDash([]);
        const r = this.rulerText(pts[0], pts[1]);
        this._label(c, (sp[0][0] + sp[1][0]) / 2, (sp[0][1] + sp[1][1]) / 2,
          [`L = ${r.L.toFixed(2)} мм`, `ΔX ${r.dx.toFixed(2)}  ΔY ${r.dy.toFixed(2)}`, `угол ${r.ang.toFixed(1)}°`], "#e00070", null, w, h);
      }
      c.strokeStyle = "#e00070"; c.lineWidth = 2;
      for (const [x, y] of sp) c.strokeRect(x - 4, y - 4, 8, 8);
    }
    // точка с координатами
    const t = this.tip;
    if (t) {
      const [x, y] = this.w2s(t.x, t.y);
      c.fillStyle = t.vertex ? "#ffd400" : "#fff"; c.strokeStyle = "#c00000"; c.lineWidth = 1.5;
      c.fillRect(x - 4, y - 4, 8, 8); c.strokeRect(x - 4, y - 4, 8, 8);
      this._label(c, x, y, [`X=${fnum(Math.round(t.x * 1000) / 1000)}`, `Y=${fnum(Math.round(t.y * 1000) / 1000)}`,
        `Z=${fnum(Math.round(t.z * 1000) / 1000)}`, `${t.tool !== null ? "T" + t.tool : "—"}  стр.${t.line + 1}`], "#1b1d22", toolColor(t.tool), w, h);
    }
    // шкалы
    const RT = 18, RL = 40;
    const raw = 70 / Math.max(this.k, 1e-9), p10 = 10 ** Math.floor(Math.log10(raw));
    const step = [1, 2, 5, 10].map(m => m * p10).find(v => v >= raw);
    const minor = step / 5;
    c.fillStyle = "#f3f4f6"; c.fillRect(0, 0, w, RT); c.fillRect(0, 0, RL, h);
    c.strokeStyle = "#c9ccd1"; c.lineWidth = 1; c.beginPath(); c.moveTo(0, RT + 0.5); c.lineTo(w, RT + 0.5); c.moveTo(RL + 0.5, 0); c.lineTo(RL + 0.5, h); c.stroke();
    c.font = "10px monospace"; c.fillStyle = "#333"; c.strokeStyle = "#555";
    const [xw0] = this.s2w(RL, 0), [xw1] = this.s2w(w, 0);
    for (let v = Math.floor(xw0 / minor) * minor; v <= xw1; v += minor) {
      const [sx] = this.w2s(v, 0), major = Math.abs(v / step - Math.round(v / step)) < 1e-6;
      if (sx < RL) continue;
      c.beginPath(); c.moveTo(sx, RT); c.lineTo(sx, RT - (major ? 8 : 4)); c.stroke();
      if (major) c.fillText(fnum(Math.round(v * 1000) / 1000), sx + 2, 10);
    }
    const [, yw1] = this.s2w(0, RT), [, yw0] = this.s2w(0, h);
    c.textAlign = "right";
    for (let v = Math.floor(yw0 / minor) * minor; v <= yw1; v += minor) {
      const [, sy] = this.w2s(0, v), major = Math.abs(v / step - Math.round(v / step)) < 1e-6;
      if (sy < RT) continue;
      c.beginPath(); c.moveTo(RL, sy); c.lineTo(RL - (major ? 8 : 4), sy); c.stroke();
      if (major) c.fillText(fnum(Math.round(v * 1000) / 1000), RL - 9, sy - 2);
    }
    c.textAlign = "left";
    c.fillStyle = "#e3e5e8"; c.fillRect(0, 0, RL, RT); c.fillStyle = "#555"; c.fillText("мм", 12, 12);
    if (t) {
      const [sx, sy] = this.w2s(t.x, t.y);
      c.strokeStyle = "#c00000"; c.lineWidth = 2;
      c.beginPath(); c.moveTo(sx, 0); c.lineTo(sx, RT); c.moveTo(0, sy); c.lineTo(RL, sy); c.stroke();
    }
  }
}

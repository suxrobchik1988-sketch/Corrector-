// Корректор NC (мобильная версия) — разбор УП и редактор режимов.
// Логика повторяет настольную версию (nc_korrektor.py / nc_edit.py).

export const PALETTE = ["#1f6fd1", "#d62728", "#2ca02c", "#ff7f0e", "#9467bd",
  "#8c564b", "#e377c2", "#17becf", "#bcbd22", "#555555"];
export const NO_TOOL_COLOR = "#888888";
export const RAPID_COLOR = "#9a9a9a";

export function toolColor(t) {
  if (t === null || t === undefined) return NO_TOOL_COLOR;
  return t > 0 ? PALETTE[(t - 1) % PALETTE.length] : PALETTE[0];
}

export function tint(hex, k = 0.86) {
  const c = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
  const r = c.map(v => Math.round(v + (255 - v) * k));
  return "#" + r.map(v => v.toString(16).padStart(2, "0")).join("");
}

export function fnum(v) {
  if (v === null || v === undefined || Number.isNaN(v)) return "—";
  if (Math.abs(v - Math.round(v)) < 1e-9) return String(Math.round(v));
  return v.toFixed(3).replace(/0+$/, "").replace(/\.$/, "");
}

export function fmtTime(sec) {
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

export const CODE_INFO = {
  G00: "Холостой ход (быстрое перемещение)", G01: "Рабочий ход по прямой", G02: "Дуга по часовой",
  G03: "Дуга против часовой", G04: "Пауза (выдержка)", G10: "Ввод данных (смещения)", G17: "Плоскость XY",
  G18: "Плоскость XZ", G19: "Плоскость YZ", G20: "Дюймы", G21: "Миллиметры",
  G28: "Возврат в референтную точку", G30: "Возврат во 2-ю реф. точку", G40: "Отмена коррекции на радиус",
  G41: "Коррекция радиуса слева", G42: "Коррекция радиуса справа", G43: "Коррекция на длину +",
  G49: "Отмена коррекции на длину", G53: "Перемещение в машинных координатах",
  G54: "Система координат 1", G55: "Система координат 2", G56: "Система координат 3",
  G57: "Система координат 4", G58: "Система координат 5", G59: "Система координат 6",
  G73: "Цикл сверления с ломкой стружки", G80: "Отмена цикла", G81: "Цикл сверления",
  G82: "Сверление с выдержкой", G83: "Глубокое сверление", G90: "Абсолютные координаты",
  G91: "Относительные координаты", G92: "Установка координат", G94: "Подача мм/мин",
  M00: "Останов программы (пауза)", M01: "Условный останов", M02: "Конец программы",
  M03: "Шпиндель по часовой", M04: "Шпиндель против часовой", M05: "Стоп шпинделя",
  M06: "Смена инструмента", M07: "Охлаждение туман", M08: "Охлаждение вкл", M09: "Охлаждение выкл",
  M30: "Конец программы с возвратом",
};

const TOK = /([A-Z])\s*([-+]?(?:\d+\.?\d*|\.\d+))/g;
const COMMENT = /\([^)]*\)|;.*$/g;

export function parseSpmap(text) {
  const out = {};
  for (const part of (text || "").split(/[,;\n]+/)) {
    const m = part.trim().toUpperCase().match(/^(M\d+)\s*=\s*T?(\d+)$/);
    if (m) out["M" + String(parseInt(m[1].slice(1))).padStart(2, "0")] = parseInt(m[2]);
  }
  return out;
}

export function stockLevels(cfg) {
  const th = Number(cfg.stock_thickness) || 16;
  return cfg.z_zero === "table" ? [th, 0] : [0, -th];
}

export function motionName(m) { return m === null || m === undefined ? "—" : "G" + String(m).padStart(2, "0"); }

export function arcPoints(x0, y0, x1, y1, cw, i, j, r) {
  let cx, cy;
  if (i !== undefined || j !== undefined) { cx = x0 + (i || 0); cy = y0 + (j || 0); }
  else if (r !== undefined) {
    const dx = x1 - x0, dy = y1 - y0, d = Math.hypot(dx, dy);
    if (d < 1e-9) return [[[x0, y0], [x1, y1]], 0];
    const h = Math.sqrt(Math.max(r * r - (d / 2) ** 2, 0));
    const mx = (x0 + x1) / 2, my = (y0 + y1) / 2, ux = -dy / d, uy = dx / d;
    let sign = cw ? -1 : 1; if (r < 0) sign = -sign;
    cx = mx + sign * h * ux; cy = my + sign * h * uy;
  } else return [[[x0, y0], [x1, y1]], Math.hypot(x1 - x0, y1 - y0)];
  const rad = Math.hypot(x0 - cx, y0 - cy);
  const a0 = Math.atan2(y0 - cy, x0 - cx);
  let a1 = Math.atan2(y1 - cy, x1 - cx);
  if (cw) { while (a1 >= a0 - 1e-9) a1 -= 2 * Math.PI; }
  else { while (a1 <= a0 + 1e-9) a1 += 2 * Math.PI; }
  const sweep = a1 - a0;
  const n = Math.max(6, Math.min(360, Math.floor(Math.abs(sweep) / (Math.PI / 36)) + 1));
  const pts = [];
  for (let k = 0; k <= n; k++) pts.push([cx + rad * Math.cos(a0 + sweep * k / n), cy + rad * Math.sin(a0 + sweep * k / n)]);
  pts[n] = [x1, y1];
  return [pts, rad * Math.abs(sweep)];
}

function tokens(raw) {
  let clean = raw.toUpperCase().replace(COMMENT, "");
  if (clean.trim().startsWith("%")) clean = "";
  const out = [];
  TOK.lastIndex = 0;
  let m;
  while ((m = TOK.exec(clean))) out.push([m[1], m[2]]);
  return out;
}

// ------------------------------------------------------------------ разбор программы
export function parse(text, cfg) {
  const spmap = parseSpmap(cfg.spindle_codes);
  const rapidFeed = Number(cfg.rapid_feed) || 30000;
  const maxDepth = Number(cfg.max_depth);
  const [zTop] = stockLevels(cfg);
  const R = { states: [], segs: [], changes: [], codes: {}, warnings: [], blocks: [], tools: new Map(), bounds: null, cutBounds: null };
  let tool = null, motion = 0, absl = true, plane = 17, comp = 40, wcs = 54, units = 21;
  let f = 0, s = 0, sp = 5, x = 0, y = 0, z = 0, cycleZ = null;
  const newBlock = (start, t) => ({ start, end: start, tool: t, cut: 0, rapid: 0, time: 0, moves: 0, drills: 0 });
  let block = newBlock(0, null);
  R.blocks.push(block);
  const warned = new Set();
  let bx0 = Infinity, by0 = Infinity, bx1 = -Infinity, by1 = -Infinity;
  const cb = [Infinity, Infinity, -Infinity, -Infinity];
  const warn = (idx, key, msg) => {
    const k = key + "|" + R.blocks.length;
    if (warned.has(k)) return;
    warned.add(k); R.warnings.push([idx, msg]);
  };
  const addCb = (px, py) => { cb[0] = Math.min(cb[0], px); cb[1] = Math.min(cb[1], py); cb[2] = Math.max(cb[2], px); cb[3] = Math.max(cb[3], py); };
  const lines = text.split("\n");
  for (let idx = 0; idx < lines.length; idx++) {
    const toks = tokens(lines[idx]);
    const codes = [];
    let nonmodal = null, newtool = null;
    const vals = {};
    for (const [letter, v] of toks) {
      const num = parseFloat(v);
      if (Number.isNaN(num)) continue;
      if (letter === "G") {
        const gi = Math.round(num), isInt = Math.abs(num - gi) < 1e-6;
        codes.push(isInt ? "G" + String(gi).padStart(2, "0") : "G" + v);
        if (!isInt) continue;
        if ([0, 1, 2, 3].includes(gi)) motion = gi;
        else if (gi === 80) motion = 0;
        else if (gi >= 73 && gi <= 89) motion = gi;
        else if (gi === 90 || gi === 91) absl = gi === 90;
        else if (gi >= 17 && gi <= 19) plane = gi;
        else if (gi >= 40 && gi <= 42) comp = gi;
        else if (gi >= 54 && gi <= 59) wcs = gi;
        else if (gi === 20 || gi === 21) units = gi;
        else if ([4, 10, 28, 30, 53, 92].includes(gi)) nonmodal = gi;
      } else if (letter === "M") {
        const m = Math.round(num), code = "M" + String(m).padStart(2, "0");
        codes.push(code);
        if (m >= 3 && m <= 5) sp = m;
        if (code in spmap) newtool = spmap[code];
      } else if (letter === "T") {
        const t = Math.round(num);
        codes.push("T" + t); newtool = t;
      } else if (letter === "N" || letter === "O") continue;
      else vals[letter] = num;
    }
    if ("F" in vals) f = vals.F;
    if ("S" in vals) s = vals.S;
    let change = false;
    if (newtool !== null && newtool !== tool) {
      R.changes.push([idx, newtool, tool]);
      tool = newtool; change = true;
      block.end = Math.max(block.start, idx - 1);
      block = newBlock(idx, tool); R.blocks.push(block);
    }
    const hasXYZ = "X" in vals || "Y" in vals || "Z" in vals;
    let lastSeg = null;
    if (nonmodal === 92) {
      if ("X" in vals) x = vals.X; if ("Y" in vals) y = vals.Y; if ("Z" in vals) z = vals.Z;
    } else if (nonmodal === null && hasXYZ) {
      let nx, ny, nz;
      if (absl) { nx = vals.X ?? x; ny = vals.Y ?? y; nz = vals.Z ?? z; }
      else { nx = x + (vals.X || 0); ny = y + (vals.Y || 0); nz = z + (vals.Z || 0); }
      if (motion >= 73 && motion <= 89) {
        if ("Z" in vals) cycleZ = absl ? vals.Z : z + vals.Z;
        const d = Math.hypot(nx - x, ny - y);
        if (d > 1e-9) {
          R.segs.push({ line: idx, tool, kind: "rapid", pts: [[x, y, z], [nx, ny, z]], feed: rapidFeed, len: d });
          block.rapid += d; block.time += d / rapidFeed * 60;
          if (z < zTop - 0.05) warn(idx, "RAP", `Холостой ход G00 в материале (Z${fnum(z)}) — опасно!`);
        }
        const cz = cycleZ !== null ? cycleZ : z;
        const dl = 2 * Math.abs(z - cz);
        lastSeg = { line: idx, tool, kind: "drill", pts: [[nx, ny, z], [nx, ny, cz]], feed: f || rapidFeed, len: dl };
        R.segs.push(lastSeg);
        if (f > 0) block.time += dl / f * 60;
        addCb(nx, ny);
        block.drills++; block.moves++;
        if (tool === null) warn(idx, "T", "Сверление без выбранного инструмента");
        if (sp === 5) warn(idx, "SP", "Сверление при выключенном шпинделе (нет M03/M04)");
        if (cycleZ !== null && cycleZ < maxDepth) warn(idx, "Z", `Глубина сверления Z${fnum(cycleZ)} ниже допустимой ${fnum(maxDepth)}`);
        x = nx; y = ny;
      } else {
        let pts, length, kind;
        if ((motion === 2 || motion === 3) && plane === 17) {
          const [p2, planLen] = arcPoints(x, y, nx, ny, motion === 2, vals.I, vals.J, vals.R);
          const m = Math.max(p2.length - 1, 1);
          pts = p2.map((p, k) => [p[0], p[1], z + (nz - z) * k / m]);
          length = Math.hypot(planLen, nz - z); kind = "cut";
        } else {
          pts = [[x, y, z], [nx, ny, nz]];
          length = Math.sqrt((nx - x) ** 2 + (ny - y) ** 2 + (nz - z) ** 2);
          kind = motion === 0 ? "rapid" : "cut";
        }
        if (kind === "rapid") {
          block.rapid += length; block.time += length / rapidFeed * 60;
          if (Math.min(z, nz) < zTop - 0.05 && (nz < z || Math.hypot(nx - x, ny - y) > 0.01))
            warn(idx, "RAP", `Холостой ход G00 в материале (Z${fnum(Math.min(z, nz))}) — опасно!`);
        } else {
          if (Math.min(z, nz) < zTop) for (const p of pts) addCb(p[0], p[1]);
          block.cut += length; block.moves++;
          if (f > 0) block.time += length / f * 60; else warn(idx, "F", "Рабочий ход без подачи F");
          if (sp === 5) warn(idx, "SP", "Рабочий ход при выключенном шпинделе (нет M03/M04)");
          if (tool === null) warn(idx, "T", "Рабочий ход без выбранного инструмента");
          if (nz < maxDepth) warn(idx, "Z", `Z${fnum(nz)} ниже допустимой глубины ${fnum(maxDepth)}`);
        }
        lastSeg = { line: idx, tool, kind, pts, feed: kind === "rapid" ? rapidFeed : (f || rapidFeed), len: length };
        R.segs.push(lastSeg);
        x = nx; y = ny; z = nz;
      }
      for (const p of lastSeg.pts) { bx0 = Math.min(bx0, p[0]); by0 = Math.min(by0, p[1]); bx1 = Math.max(bx1, p[0]); by1 = Math.max(by1, p[1]); }
    }
    for (const c of codes) (R.codes[c] ||= []).push(idx);
    R.states.push({ tool, motion, absl, plane, comp, wcs, units, f, s, sp, x, y, z, codes, change });
  }
  block.end = Math.max(block.start, lines.length - 1);
  if (R.blocks.length > 1 && R.blocks[0].tool === null && R.blocks[0].moves === 0 && R.blocks[0].rapid === 0) R.blocks.shift();
  for (const b of R.blocks) {
    const t = R.tools.get(b.tool) || newBlock(b.start, b.tool);
    t.cut += b.cut; t.rapid += b.rapid; t.time += b.time; t.moves += b.moves; t.drills += b.drills;
    R.tools.set(b.tool, t);
  }
  if (bx0 < Infinity) R.bounds = [bx0, by0, bx1, by1];
  if (cb[0] < Infinity) R.cutBounds = cb;
  return R;
}

// ------------------------------------------------------------------ импорт библиотеки инструментов
export function importToolsJSON(data) {
  const found = [];
  const num = v => { const x = parseFloat(String(v).replace(",", ".")); return Number.isFinite(x) ? x : null; };
  const walk = (o, hint) => {
    if (Array.isArray(o)) { o.forEach((v, n) => walk(v, n + 1)); return; }
    if (!o || typeof o !== "object") return;
    const low = {};
    for (const [k, v] of Object.entries(o)) low[String(k).toLowerCase()] = v;
    let d = null;
    for (const k of ["diameter", "diam", "d", "dia", "диаметр"]) if (k in low && num(low[k])) { d = num(low[k]); break; }
    if (d) {
      let tno = null;
      for (const k of ["t", "tool", "number", "num", "no", "slot", "spindle", "position", "шпиндель", "номер"]) {
        if (k in low) { const m = String(low[k]).match(/\d+/); if (m) { tno = parseInt(m[0]); break; } }
      }
      if (tno === null) tno = hint;
      const typ = String(low.type ?? low.kind ?? low["тип"] ?? "").toLowerCase();
      found.push([tno, { name: String(low.name ?? low.title ?? low["название"] ?? ""), d, type: /drill|свер/.test(typ) ? "drill" : "mill" }]);
      return;
    }
    for (const [k, v] of Object.entries(o)) { const m = String(k).trim().match(/^T?(\d+)$/i); walk(v, m ? parseInt(m[1]) : null); }
  };
  walk(data, null);
  const out = {};
  found.forEach(([t, info], n) => { out[String(t || n + 1)] = info; });
  return out;
}

// ------------------------------------------------------------------ редактор режимов (nc_edit)
export const ENTRY_NAMES = { none: "Не менять", ramp3d: "Наклонное 3D", zigzag: "Зигзаг" };

const fmt = v => { v = Math.round(v * 1000) / 1000; if (Math.abs(v) < 5e-4) v = 0; return v.toFixed(3); };
const ffeed = v => Math.abs(v - Math.round(v)) < 1e-6 ? String(Math.round(v)) : v.toFixed(1);

class Prim {
  static line(a, b) {
    const p = new Prim(); p.kind = "L"; p.a = a; p.b = b; p.c = null; p.cw = false; p.r = 0; p.a0 = 0; p.sweep = 0;
    p.L = Math.hypot(b[0] - a[0], b[1] - a[1]); return p;
  }
  static arc(a, b, c, cw, sweep) {
    const p = new Prim(); p.kind = "A"; p.a = a; p.b = b; p.c = c; p.cw = cw;
    p.r = Math.hypot(a[0] - c[0], a[1] - c[1]); p.a0 = Math.atan2(a[1] - c[1], a[0] - c[0]);
    if (sweep === undefined) {
      let a1 = Math.atan2(b[1] - c[1], b[0] - c[0]);
      if (cw) { while (a1 >= p.a0 - 1e-9) a1 -= 2 * Math.PI; } else { while (a1 <= p.a0 + 1e-9) a1 += 2 * Math.PI; }
      sweep = a1 - p.a0;
    }
    p.sweep = sweep; p.L = p.r * Math.abs(sweep); return p;
  }
  point(t) {
    if (this.kind === "L") return [this.a[0] + (this.b[0] - this.a[0]) * t, this.a[1] + (this.b[1] - this.a[1]) * t];
    const ang = this.a0 + this.sweep * t;
    return [this.c[0] + this.r * Math.cos(ang), this.c[1] + this.r * Math.sin(ang)];
  }
  sub(t0, t1) {
    const a = t0 <= 0 ? this.a : this.point(t0), b = t1 >= 1 ? this.b : this.point(t1);
    return this.kind === "L" ? Prim.line(a, b) : Prim.arc(a, b, this.c, this.cw, this.sweep * (t1 - t0));
  }
  rev() { return this.kind === "L" ? Prim.line(this.b, this.a) : Prim.arc(this.b, this.a, this.c, !this.cw, -this.sweep); }
}

function arcCenter(x0, y0, x1, y1, cw, i, j, r) {
  if (i !== undefined || j !== undefined) return [x0 + (i || 0), y0 + (j || 0)];
  if (r === undefined) return null;
  const dx = x1 - x0, dy = y1 - y0, d = Math.hypot(dx, dy);
  if (d < 1e-9) return null;
  const h = Math.sqrt(Math.max(r * r - (d / 2) ** 2, 0));
  let sign = cw ? -1 : 1; if (r < 0) sign = -sign;
  return [(x0 + x1) / 2 + sign * h * (-dy / d), (y0 + y1) / 2 + sign * h * (dx / d)];
}

function cutRange(prims, s0, s1) {
  const out = []; let acc = 0;
  for (const p of prims) {
    const e0 = acc, e1 = acc + p.L; acc = e1;
    if (p.L <= 1e-12 || e1 <= s0 + 1e-9 || e0 >= s1 - 1e-9) continue;
    const t0 = Math.max(0, (s0 - e0) / p.L), t1 = Math.min(1, (s1 - e0) / p.L);
    if (t1 - t0 > 1e-9) out.push(p.sub(t0, t1));
  }
  return out;
}

function walkWrap(prims, total, P) {
  const out = []; let s = 0;
  while (s < total - 1e-9) { const take = Math.min(P, total - s); out.push(...cutRange(prims, 0, take)); s += take; }
  return out;
}

class Emitter {
  constructor() { this.lines = []; this.f = null; this.motion = null; this.z = null; }
  move(p, zEnd, feed) {
    const g = p.kind === "L" ? 1 : (p.cw ? 2 : 3);
    const w = ["G0" + g, "X" + fmt(p.b[0]), "Y" + fmt(p.b[1])];
    if (this.z === null || Math.abs(zEnd - this.z) > 5e-4) w.push("Z" + fmt(zEnd));
    if (p.kind === "A") { w.push("I" + fmt(p.c[0] - p.a[0])); w.push("J" + fmt(p.c[1] - p.a[1])); }
    if (feed !== null && feed !== undefined && (this.f === null || Math.abs(feed - this.f) > 1e-6)) { w.push("F" + ffeed(feed)); this.f = feed; }
    this.lines.push(w.join(" ")); this.motion = g; this.z = zEnd;
  }
  zmove(z, feed) {
    const w = ["G01", "Z" + fmt(z)];
    if (feed !== null && feed !== undefined && (this.f === null || Math.abs(feed - this.f) > 1e-6)) { w.push("F" + ffeed(feed)); this.f = feed; }
    this.lines.push(w.join(" ")); this.motion = 1; this.z = z;
  }
  pieces(pieces, zFrom, zTo, feed) {
    const tot = pieces.reduce((a, p) => a + p.L, 0) || 1; let acc = 0;
    for (const p of pieces) { acc += p.L; this.move(p, zFrom + (zTo - zFrom) * acc / tot, feed); }
  }
}

function parseLine(raw) {
  const g = [], m = []; let t = null; const vals = {};
  for (const [letter, v] of tokens(raw)) {
    const num = parseFloat(v); if (Number.isNaN(num)) continue;
    if (letter === "G") g.push(num);
    else if (letter === "M") m.push(Math.round(num));
    else if (letter === "T") t = Math.round(num);
    else if (letter === "N" || letter === "O") continue;
    else vals[letter] = num;
  }
  return { g, m, t, vals };
}

function setWord(raw, letter, valueText) {
  const parts = raw.split(/(\([^)]*\)|;.*$)/);
  const rx = new RegExp("(?<![A-Za-z])" + letter + "\\s*[-+]?(?:\\d+\\.?\\d*|\\.\\d+)", "i");
  for (let k = 0; k < parts.length; k += 2) {
    if (rx.test(parts[k])) { parts[k] = parts[k].replace(rx, letter + valueText); return parts.join(""); }
  }
  const code = parts[0].replace(/\s+$/, "");
  const rest = raw.slice(parts[0].length);
  return (code ? code + " " : "") + letter + valueText + (rest ? " " + rest : "");
}

function prependWord(raw, word) {
  const m = raw.match(/^\s*(N\d+\s*)/i);
  if (m) return raw.slice(0, m[0].length) + word + " " + raw.slice(m[0].length);
  const lead = raw.length - raw.replace(/^\s+/, "").length;
  return raw.slice(0, lead) + word + " " + raw.slice(lead);
}

function emitFlat(em, pieces, prims, feeds, fCut, z, offset) {
  if (!pieces.length) return;
  const bounds = []; let acc = 0;
  prims.forEach((p, k) => { bounds.push([acc, acc + p.L, feeds[k]]); acc += p.L; });
  let s = offset;
  for (const p of pieces) {
    let feed = fCut;
    if (feed === null || feed === undefined) {
      feed = feeds[feeds.length - 1];
      for (const [b0, b1, f] of bounds) if (b0 - 1e-6 <= s && s < b1 - 1e-9) { feed = f; break; }
    }
    em.move(p, z, feed); s += p.L; if (s >= acc - 1e-9) s -= acc;
  }
}

const isMotionG = gv => { const gi = Math.round(gv); return Math.abs(gv - gi) < 1e-6 && ((gi >= 0 && gi <= 3) || (gi >= 73 && gi <= 89)); };

export function transform(text, rules, zTop = 0, clearance = 1, toolTypes = {}, spmap = {}) {
  const lines = text.split("\n"), out = [], rep = {};
  const RR = t => (rep[t] ||= { found: 0, ramps: 0, S: 0, F: 0, skipped: 0 });
  let tool = null, absl = true, plane = 17, mO = 0, fO = 0, x = 0, y = 0, z = 0;
  const em = new Emitter(); em.motion = 0; em.f = null;
  let ox = 0, oy = 0, tail = null;

  const lineState = (g, mCur) => {
    let mot = mCur, nonmodal = false;
    for (const gv of g) {
      const gi = Math.round(gv); if (Math.abs(gv - gi) > 1e-6) continue;
      if (gi >= 0 && gi <= 3) mot = gi; else if (gi === 80) mot = 0; else if (gi >= 73 && gi <= 89) mot = gi;
      else if (gi === 90 || gi === 91) absl = gi === 90; else if (gi >= 17 && gi <= 19) plane = gi;
      else if ([4, 10, 28, 30, 53, 92].includes(gi)) nonmodal = true;
    }
    return [mot, nonmodal];
  };
  const flushTail = isCut => {
    if (!tail) return;
    const [pieces, depth, feed] = tail;
    if (isCut) {
      em.z = depth; em.pieces(pieces, depth, depth, feed); out.push(...em.lines); em.lines = [];
      if (pieces.length) [ox, oy] = pieces[pieces.length - 1].b;
    }
    tail = null;
  };

  let i = 0;
  const n = lines.length;
  while (i < n) {
    const raw = lines[i];
    const { g, m: mcodes, t, vals } = parseLine(raw);
    if (t !== null) tool = t;
    for (const mc of mcodes) { const k = "M" + String(mc).padStart(2, "0"); if (k in spmap) tool = spmap[k]; }
    const rule = rules[tool] || {};
    const typ = toolTypes[tool] || "mill";
    const [mot, nonmodal] = lineState(g, mO);
    const gMotionInLine = g.some(isMotionG);
    const hasXY = "X" in vals || "Y" in vals;
    const hasMove = (hasXY || "Z" in vals) && !nonmodal;
    let nx, ny, nz;
    if (absl) { nx = vals.X ?? x; ny = vals.Y ?? y; nz = vals.Z ?? z; }
    else { nx = x + (vals.X || 0); ny = y + (vals.Y || 0); nz = z + (vals.Z || 0); }

    const isPlunge = hasMove && mot === 1 && absl && plane === 17 && !mcodes.length && t === null &&
      Math.abs(nx - x) < 1e-4 && Math.abs(ny - y) < 1e-4 && nz < z - 1e-4 && nz < zTop - 1e-4 && tool !== null;
    if (isPlunge) {
      const prims = [], feeds = [];
      let px = nx, py = ny, mm = 1, ff = vals.F ?? fO, j = i + 1;
      while (j < n) {
        const L = parseLine(lines[j]);
        if (L.m.length || L.t !== null) break;
        let okG = true, motJ = mm;
        for (const gv of L.g) {
          const gi = Math.round(gv);
          if (Math.abs(gv - gi) > 1e-6) okG = false; else if (gi >= 1 && gi <= 3) motJ = gi; else if (gi !== 17 && gi !== 90) okG = false;
        }
        if (!okG || motJ < 1 || motJ > 3) break;
        if (!("X" in L.vals || "Y" in L.vals)) break;
        if ("Z" in L.vals && Math.abs(L.vals.Z - nz) > 1e-4) break;
        const qx = L.vals.X ?? px, qy = L.vals.Y ?? py;
        let pr;
        if (motJ === 1) pr = Prim.line([px, py], [qx, qy]);
        else {
          const c = arcCenter(px, py, qx, qy, motJ === 2, L.vals.I, L.vals.J, L.vals.R);
          if (!c) break;
          pr = Prim.arc([px, py], [qx, qy], c, motJ === 2);
        }
        if ("F" in L.vals) ff = L.vals.F;
        prims.push(pr); feeds.push(ff); px = qx; py = qy; mm = motJ; j++;
      }
      const P = prims.reduce((a, p) => a + p.L, 0);
      const entry = rule.entry || "none";
      if (P > 1e-6) RR(tool).found++;
      if (entry !== "none" && typ !== "drill" && P > 1) {
        flushTail(false);
        const ang = Math.max(0.5, Math.min(45, Number(rule.angle) || 5));
        const zStart = Math.min(z, zTop + Math.max(0, clearance)), zEnd = nz;
        const depth = Math.max(zStart - zEnd, 0);
        const L = depth > 0 ? depth / Math.tan(ang * Math.PI / 180) : 0;
        const fPlunge = rule.Fz || vals.F || fO || fO;
        const fCut = rule.F ?? null;
        const closed = Math.hypot(prims[0].a[0] - prims[prims.length - 1].b[0], prims[0].a[1] - prims[prims.length - 1].b[1]) < 0.01;
        em.lines = []; em.z = z;
        if (Math.abs(ox - x) > 1e-4 || Math.abs(oy - y) > 1e-4) { em.lines.push(`G00 X${fmt(x)} Y${fmt(y)}`); em.motion = 0; }
        if (z > zStart + 1e-4) em.zmove(zStart, fPlunge);
        const mode = (entry === "zigzag" || closed) ? entry : "zigzag";
        let endXY = prims[prims.length - 1].b, newTail = null;
        if (mode === "ramp3d") {
          em.pieces(walkWrap(prims, L, P), zStart, zEnd, fPlunge);
          const sR = L % P;
          let rest, wedge;
          if (sR > 1e-6) { rest = cutRange(prims, sR, P); wedge = cutRange(prims, 0, sR); } else { rest = prims.slice(); wedge = []; }
          emitFlat(em, rest, prims, feeds, fCut, zEnd, sR);
          emitFlat(em, wedge, prims, feeds, fCut, zEnd, 0);
          endXY = wedge.length ? wedge[wedge.length - 1].b : rest[rest.length - 1].b;
          if (sR > 1e-6) newTail = [cutRange(prims, sR, P), zEnd, fCut ?? feeds[feeds.length - 1]];
        } else {
          const zl = Math.max(1, Math.min(Number(rule.zig) || 50, P));
          let legs = L > 0 ? Math.max(2, Math.ceil(L / zl)) : 0;
          if (legs % 2) legs++;
          const fwd = cutRange(prims, 0, zl), back = fwd.slice().reverse().map(p => p.rev());
          const dz = legs ? depth / legs : 0;
          let zc = zStart;
          for (let k = 0; k < legs; k++) { em.pieces(k % 2 === 0 ? fwd : back, zc, zc - dz, fPlunge); zc -= dz; }
          if (!legs) em.zmove(zEnd, fPlunge);
          emitFlat(em, prims.slice(), prims, feeds, fCut, zEnd, 0);
        }
        out.push(...em.lines); em.lines = [];
        RR(tool).ramps++;
        fO = ff; mO = mm; x = px; y = py; z = nz;
        [ox, oy] = endXY;
        tail = (Math.abs(ox - x) > 1e-4 || Math.abs(oy - y) > 1e-4) ? newTail : null;
        i = j; continue;
      } else if (entry !== "none" && P <= 1) RR(tool).skipped++;
    }

    let nw = raw;
    if (tail) {
      if (hasMove && mot >= 1 && mot <= 3 && !(!hasXY && nz > z)) flushTail(true);
      else if (hasMove) tail = null;
    }
    if (rule.S != null && "S" in vals && Math.abs(vals.S - rule.S) > 1e-6) { nw = setWord(nw, "S", ffeed(rule.S)); RR(tool).S++; }
    const fLine = "F" in vals ? vals.F : null;
    if (fLine !== null) fO = fLine;
    if (hasMove && mot >= 1 && mot <= 3) {
      const verticalDown = !hasXY && nz < z;
      let want = fO;
      if (verticalDown && rule.Fz != null) want = rule.Fz;
      else if (!verticalDown && rule.F != null) want = rule.F;
      if (want > 0) {
        const need = (fLine !== null && Math.abs(fLine - want) > 1e-6) || (fLine === null && (em.f === null || Math.abs(want - em.f) > 1e-6));
        if (need) { nw = setWord(nw, "F", ffeed(want)); if (Math.abs(want - fO) > 1e-6) RR(tool).F++; }
        em.f = want;
      }
    } else if (fLine !== null) em.f = fLine;
    if (gMotionInLine) em.motion = mot;
    if (hasMove && !nonmodal) {
      if (!gMotionInLine && em.motion !== mot) nw = prependWord(nw, mot < 10 ? "G0" + mot : "G" + mot);
      if (hasXY && (Math.abs(ox - x) > 1e-4 || Math.abs(oy - y) > 1e-4) && absl) {
        if (!("X" in vals)) nw = setWord(nw, "X", fmt(x));
        if (!("Y" in vals)) nw = setWord(nw, "Y", fmt(y));
      }
      em.motion = mot;
    }
    out.push(nw);
    mO = mot;
    if (hasMove && !nonmodal) { x = nx; y = ny; z = nz; if (hasXY) { ox = x; oy = y; } }
    i++;
  }
  return [out.join("\n"), rep];
}
